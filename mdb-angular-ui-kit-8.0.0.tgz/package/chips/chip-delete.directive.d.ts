import { InjectionToken } from '@angular/core';
import * as i0 from "@angular/core";
export interface MdbChipParent {
    editing: boolean;
    delete(): void;
}
export declare const MDB_CHIP_PARENT: InjectionToken<MdbChipParent>;
export declare class MdbChipDeleteDirective {
    protected _chipParent: MdbChipParent;
    constructor(_chipParent: MdbChipParent);
    handleClick(): void;
    get display(): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbChipDeleteDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbChipDeleteDirective, "[mdbChipDelete]", never, {}, {}, never, never, false, never>;
}
