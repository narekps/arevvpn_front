import { BooleanInput } from '@angular/cdk/coercion';
import { ElementRef, EventEmitter } from '@angular/core';
import * as i0 from "@angular/core";
export interface MdbChipEditedEvent {
    chip: MdbChipComponent;
    value: string;
}
export declare class MdbChipComponent {
    private _elementRef;
    private _chipContainer;
    customClass: string;
    get editable(): boolean;
    set editable(value: boolean);
    private _editable;
    edited: EventEmitter<MdbChipEditedEvent>;
    deleted: EventEmitter<void>;
    handleDoubleClick(): void;
    handleKeydown(event: KeyboardEvent): void;
    handleBlur(): void;
    protected editing: boolean;
    constructor(_elementRef: ElementRef);
    activateEditMode(): void;
    cancelEditMode(): void;
    emitEditedEvent(value: string): void;
    delete(): void;
    static ngAcceptInputType_editable: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbChipComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbChipComponent, "mdb-chip", never, { "customClass": { "alias": "customClass"; "required": false; }; "editable": { "alias": "editable"; "required": false; }; }, { "edited": "edited"; "deleted": "deleted"; }, never, ["*"], false, never>;
}
