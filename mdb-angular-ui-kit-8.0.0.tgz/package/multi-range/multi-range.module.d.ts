import * as i0 from "@angular/core";
import * as i1 from "./multi-range.component";
import * as i2 from "./multi-range-thumb.directive";
import * as i3 from "@angular/forms";
import * as i4 from "@angular/common";
export declare class MdbMultiRangeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbMultiRangeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbMultiRangeModule, [typeof i1.MdbMultiRangeComponent, typeof i2.MdbMultiRangeThumbDirective], [typeof i3.FormsModule, typeof i4.CommonModule], [typeof i1.MdbMultiRangeComponent, typeof i2.MdbMultiRangeThumbDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbMultiRangeModule>;
}
