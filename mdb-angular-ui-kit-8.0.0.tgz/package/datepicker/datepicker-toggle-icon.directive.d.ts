import { InjectionToken, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare const MDB_DATEPICKER_TOGGLE_ICON: InjectionToken<MdbDatepickerToggleIconDirective>;
export declare class MdbDatepickerToggleIconDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbDatepickerToggleIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbDatepickerToggleIconDirective, "[mdbDatepickerToggleIcon]", never, {}, {}, never, never, false, never>;
}
