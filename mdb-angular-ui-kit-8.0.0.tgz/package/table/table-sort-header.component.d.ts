import { BooleanInput } from '@angular/cdk/coercion';
import { OnDestroy, OnInit } from '@angular/core';
import { MdbTableSortDirective, MdbSortDirection } from './table-sort.directive';
import * as i0 from "@angular/core";
export declare class MdbTableSortHeaderDirective implements OnInit, OnDestroy {
    private _sort;
    get disableSort(): boolean;
    set disableSort(value: boolean);
    private _disableSort;
    get forceSort(): boolean;
    set forceSort(value: boolean);
    private _forceSort;
    get name(): string;
    set name(value: string);
    private _name;
    direction: MdbSortDirection;
    get rotate(): string;
    get cursor(): "" | "pointer";
    onClick(): void;
    constructor(_sort: MdbTableSortDirective);
    private _toCamelCase;
    private _getSortingDirection;
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ngAcceptInputType_disableSort: BooleanInput;
    static ngAcceptInputType_forceSort: BooleanInput;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTableSortHeaderDirective, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbTableSortHeaderDirective, "[mdbTableSortHeader]", never, { "disableSort": { "alias": "disableSort"; "required": false; }; "forceSort": { "alias": "forceSort"; "required": false; }; "name": { "alias": "mdbTableSortHeader"; "required": false; }; }, {}, never, ["*"], false, never>;
}
