import { OverlayRef } from '@angular/cdk/overlay';
import { Observable } from 'rxjs';
import { MdbPopconfirmContainerComponent } from './popconfirm-container.component';
export declare class MdbPopconfirmRef<T> {
    overlayRef: OverlayRef;
    private _popconfirmContainerRef;
    constructor(overlayRef: OverlayRef, _popconfirmContainerRef: MdbPopconfirmContainerComponent);
    component: T;
    private readonly onClose$;
    private readonly onConfirm$;
    readonly onClose: Observable<any>;
    readonly onConfirm: Observable<any>;
    close(message?: any): void;
    confirm(message?: any): void;
    getPosition(): DOMRect;
}
