import { QueryList } from '@angular/core';
import { MdbCollapseDirective } from 'mdb-angular-ui-kit/collapse';
import * as i0 from "@angular/core";
export declare class MdbSidenavMenuDirective {
    collapses: QueryList<MdbCollapseDirective>;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbSidenavMenuDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbSidenavMenuDirective, "[mdbSidenavMenu]", never, {}, {}, ["collapses"], never, false, never>;
}
