import * as i0 from "@angular/core";
import * as i1 from "./timepicker.component";
import * as i2 from "./timepicker-toggle.component";
import * as i3 from "./timepicker.directive";
import * as i4 from "./timepicker.content";
import * as i5 from "./timepicker-toggle-icon.directive";
import * as i6 from "@angular/common";
import * as i7 from "@angular/cdk/overlay";
import * as i8 from "@angular/cdk/a11y";
import * as i9 from "@angular/cdk/portal";
export declare class MdbTimepickerModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTimepickerModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbTimepickerModule, [typeof i1.MdbTimepickerComponent, typeof i2.MdbTimepickerToggleComponent, typeof i3.MdbTimepickerDirective, typeof i4.MdbTimepickerContentComponent, typeof i5.MdbTimepickerToggleIconDirective], [typeof i6.CommonModule, typeof i7.OverlayModule, typeof i8.A11yModule, typeof i9.PortalModule], [typeof i1.MdbTimepickerComponent, typeof i2.MdbTimepickerToggleComponent, typeof i3.MdbTimepickerDirective, typeof i5.MdbTimepickerToggleIconDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbTimepickerModule>;
}
