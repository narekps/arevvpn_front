import { OnInit, ChangeDetectorRef, ElementRef, TemplateRef, ViewContainerRef, AfterContentInit } from '@angular/core';
import { MdbTimepickerComponent } from './timepicker.component';
import { TemplatePortal } from '@angular/cdk/portal';
import * as i0 from "@angular/core";
export declare class MdbTimepickerToggleComponent implements OnInit, AfterContentInit {
    private _cdRef;
    private _vcr;
    button: ElementRef<HTMLElement>;
    _iconRef: TemplateRef<any>;
    mdbTimepickerToggle: MdbTimepickerComponent;
    icon: string;
    disabled: boolean;
    handleClick(): void;
    get iconRef(): TemplatePortal | null;
    private _iconPortal;
    constructor(_cdRef: ChangeDetectorRef, _vcr: ViewContainerRef);
    ngOnInit(): void;
    ngAfterContentInit(): void;
    private _createIconPortal;
    markForCheck(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTimepickerToggleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MdbTimepickerToggleComponent, "mdb-timepicker-toggle", never, { "mdbTimepickerToggle": { "alias": "mdbTimepickerToggle"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, {}, ["_iconRef"], never, false, never>;
    static ngAcceptInputType_disabled: unknown;
}
