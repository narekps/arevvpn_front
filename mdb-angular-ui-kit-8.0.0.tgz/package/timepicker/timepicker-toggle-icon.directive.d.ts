import { InjectionToken, TemplateRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare const MDB_TIMEPICKER_TOGGLE_ICON: InjectionToken<MdbTimepickerToggleIconDirective>;
export declare class MdbTimepickerToggleIconDirective {
    template: TemplateRef<any>;
    constructor(template: TemplateRef<any>);
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbTimepickerToggleIconDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<MdbTimepickerToggleIconDirective, "[mdbTimepickerToggleIcon]", never, {}, {}, never, never, false, never>;
}
