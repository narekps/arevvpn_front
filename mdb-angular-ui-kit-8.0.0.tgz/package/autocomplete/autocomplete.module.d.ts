import * as i0 from "@angular/core";
import * as i1 from "./autocomplete.component";
import * as i2 from "./autocomplete.directive";
import * as i3 from "@angular/common";
import * as i4 from "@angular/forms";
import * as i5 from "mdb-angular-ui-kit/option";
import * as i6 from "@angular/cdk/overlay";
export declare class MdbAutocompleteModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<MdbAutocompleteModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<MdbAutocompleteModule, [typeof i1.MdbAutocompleteComponent, typeof i2.MdbAutocompleteDirective], [typeof i3.CommonModule, typeof i4.FormsModule, typeof i5.MdbOptionModule, typeof i6.OverlayModule], [typeof i1.MdbAutocompleteComponent, typeof i2.MdbAutocompleteDirective, typeof i5.MdbOptionModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<MdbAutocompleteModule>;
}
