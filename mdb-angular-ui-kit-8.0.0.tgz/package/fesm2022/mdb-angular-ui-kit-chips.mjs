import * as i0 from '@angular/core';
import { EventEmitter, HostListener, Output, Directive, InjectionToken, HostBinding, Inject, Input, ViewChild, ChangeDetectionStrategy, Component, ElementRef, ContentChildren, ContentChild, NgModule } from '@angular/core';
import { MdbAbstractFormControl } from 'mdb-angular-ui-kit/forms';
import { Subject } from 'rxjs';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { takeUntil } from 'rxjs/operators';
import { CommonModule } from '@angular/common';

class MdbChipsInputDirective {
    _elementRef;
    _cdRef;
    chipAdd = new EventEmitter();
    onKeydown(event) {
        if (this._isConfirmKey(event)) {
            this._emitChipAddEvent();
        }
        if (this._isDeleteKey(event) && !this.input.value) {
            this.deleteChip.next();
        }
    }
    onFocusOut() {
        if (this.input.value) {
            this._emitChipAddEvent();
        }
    }
    get input() {
        return this._elementRef.nativeElement;
    }
    get hasValue() {
        return !!this.input.value;
    }
    get labelActive() {
        return this.hasValue || this._hasItems;
    }
    stateChanges = new Subject();
    deleteChip = new Subject();
    _confirmKeys = ['Enter'];
    _removeKeys = ['Backspace', 'Delete'];
    _hasItems = false;
    constructor(_elementRef, _cdRef) {
        this._elementRef = _elementRef;
        this._cdRef = _cdRef;
    }
    _isConfirmKey(event) {
        return this._confirmKeys.includes(event.key);
    }
    _isDeleteKey(event) {
        return this._removeKeys.includes(event.key);
    }
    _emitChipAddEvent() {
        const event = {
            value: this.input.value,
            input: this,
        };
        this.chipAdd.emit(event);
    }
    clear() {
        this.input.value = '';
    }
    _updateLabelState(value) {
        this._hasItems = value;
        this.stateChanges.next();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipsInputDirective, deps: [{ token: i0.ElementRef }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.1", type: MdbChipsInputDirective, isStandalone: false, selector: "[mdbChipsInput]", outputs: { chipAdd: "chipAdd" }, host: { listeners: { "keydown": "onKeydown($event)", "blur": "onFocusOut()" } }, providers: [{ provide: MdbAbstractFormControl, useExisting: MdbChipsInputDirective }], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipsInputDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[mdbChipsInput]',
                    providers: [{ provide: MdbAbstractFormControl, useExisting: MdbChipsInputDirective }],
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.ChangeDetectorRef }], propDecorators: { chipAdd: [{
                type: Output
            }], onKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }], onFocusOut: [{
                type: HostListener,
                args: ['blur']
            }] } });

const MDB_CHIP_PARENT = new InjectionToken('MDB_CHIP_PARENT');
class MdbChipDeleteDirective {
    _chipParent;
    constructor(_chipParent) {
        this._chipParent = _chipParent;
    }
    handleClick() {
        this._chipParent.delete();
    }
    get display() {
        return this._chipParent.editing;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipDeleteDirective, deps: [{ token: MDB_CHIP_PARENT }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.1", type: MdbChipDeleteDirective, isStandalone: false, selector: "[mdbChipDelete]", host: { listeners: { "click": "handleClick()" }, properties: { "class.d-none": "this.display" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipDeleteDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[mdbChipDelete]',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [MDB_CHIP_PARENT]
                }] }], propDecorators: { handleClick: [{
                type: HostListener,
                args: ['click']
            }], display: [{
                type: HostBinding,
                args: ['class.d-none']
            }] } });

class MdbChipComponent {
    _elementRef;
    _chipContainer;
    customClass = '';
    get editable() {
        return this._editable;
    }
    set editable(value) {
        this._editable = coerceBooleanProperty(value);
    }
    _editable = false;
    edited = new EventEmitter();
    deleted = new EventEmitter();
    handleDoubleClick() {
        if (this.editable && !this.editing) {
            this.activateEditMode();
        }
    }
    handleKeydown(event) {
        if (event.key === 'Enter' && this.editing) {
            this.cancelEditMode();
        }
    }
    handleBlur() {
        if (this.editing) {
            this.cancelEditMode();
        }
    }
    editing = false;
    constructor(_elementRef) {
        this._elementRef = _elementRef;
    }
    activateEditMode() {
        this.editing = true;
        setTimeout(() => {
            this._chipContainer.nativeElement.focus();
        }, 0);
    }
    cancelEditMode() {
        const text = this._elementRef.nativeElement.querySelector('.text-chip').textContent;
        this.emitEditedEvent(text);
        this.editing = false;
    }
    emitEditedEvent(value) {
        const event = {
            chip: this,
            value: value,
        };
        this.edited.emit(event);
    }
    delete() {
        this.deleted.emit();
    }
    static ngAcceptInputType_editable;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbChipComponent, isStandalone: false, selector: "mdb-chip", inputs: { customClass: "customClass", editable: "editable" }, outputs: { edited: "edited", deleted: "deleted" }, host: { listeners: { "dblclick": "handleDoubleClick()", "keydown": "handleKeydown($event)", "focusout": "handleBlur()" } }, providers: [{ provide: MDB_CHIP_PARENT, useExisting: MdbChipComponent }], viewQueries: [{ propertyName: "_chipContainer", first: true, predicate: ["chipContainer"], descendants: true, static: true }], ngImport: i0, template: "<div class=\"chip btn {{ customClass }}\" [attr.contenteditable]=\"editing\" #chipContainer>\n  <ng-content></ng-content>\n</div>\n", changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-chip', changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: MDB_CHIP_PARENT, useExisting: MdbChipComponent }], standalone: false, template: "<div class=\"chip btn {{ customClass }}\" [attr.contenteditable]=\"editing\" #chipContainer>\n  <ng-content></ng-content>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { _chipContainer: [{
                type: ViewChild,
                args: ['chipContainer', { static: true }]
            }], customClass: [{
                type: Input
            }], editable: [{
                type: Input
            }], edited: [{
                type: Output
            }], deleted: [{
                type: Output
            }], handleDoubleClick: [{
                type: HostListener,
                args: ['dblclick']
            }], handleKeydown: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }], handleBlur: [{
                type: HostListener,
                args: ['focusout']
            }] } });

class MdbChipsComponent {
    chipsInput;
    inputEl;
    chips;
    _destroy$ = new Subject();
    chipsClass = true;
    chipsInitial = true;
    onFocus(event) {
        const classList = event.target.classList;
        if (classList.contains('chip') ||
            classList.contains('close') ||
            classList.contains('text-chip')) {
            return;
        }
        this.inputEl.nativeElement.focus();
    }
    constructor() { }
    ngAfterContentInit() {
        if (this.chips.length) {
            this.chipsInput._hasItems = true;
            this.chipsInput.stateChanges.next();
        }
        this.chips.changes.pipe(takeUntil(this._destroy$)).subscribe(() => {
            const hasItems = !!this.chips.length;
            this.chipsInput._hasItems = hasItems;
            this.chipsInput.stateChanges.next();
        });
        this.chipsInput.deleteChip.pipe(takeUntil(this._destroy$)).subscribe(() => {
            const lastChip = this.chips.last;
            if (lastChip) {
                lastChip.delete();
            }
        });
    }
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipsComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbChipsComponent, isStandalone: false, selector: "mdb-chips", host: { listeners: { "click": "onFocus($event)" }, properties: { "class.chips": "this.chipsClass", "class.chips-initial": "this.chipsInitial" } }, queries: [{ propertyName: "chipsInput", first: true, predicate: MdbChipsInputDirective, descendants: true }, { propertyName: "inputEl", first: true, predicate: MdbChipsInputDirective, descendants: true, read: ElementRef, static: true }, { propertyName: "chips", predicate: MdbChipComponent, descendants: true }], ngImport: i0, template: "<ng-content></ng-content>\n", changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipsComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-chips', changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<ng-content></ng-content>\n" }]
        }], ctorParameters: () => [], propDecorators: { chipsInput: [{
                type: ContentChild,
                args: [MdbChipsInputDirective]
            }], inputEl: [{
                type: ContentChild,
                args: [MdbChipsInputDirective, { read: ElementRef, static: true }]
            }], chips: [{
                type: ContentChildren,
                args: [MdbChipComponent, { descendants: true }]
            }], chipsClass: [{
                type: HostBinding,
                args: ['class.chips']
            }], chipsInitial: [{
                type: HostBinding,
                args: ['class.chips-initial']
            }], onFocus: [{
                type: HostListener,
                args: ['click', ['$event']]
            }] } });

class MdbChipsModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipsModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbChipsModule, declarations: [MdbChipsInputDirective,
            MdbChipsComponent,
            MdbChipComponent,
            MdbChipDeleteDirective], imports: [CommonModule], exports: [MdbChipsInputDirective, MdbChipsComponent, MdbChipComponent, MdbChipDeleteDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipsModule, imports: [CommonModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbChipsModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        MdbChipsInputDirective,
                        MdbChipsComponent,
                        MdbChipComponent,
                        MdbChipDeleteDirective,
                    ],
                    exports: [MdbChipsInputDirective, MdbChipsComponent, MdbChipComponent, MdbChipDeleteDirective],
                    imports: [CommonModule],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MdbChipComponent, MdbChipDeleteDirective, MdbChipsComponent, MdbChipsInputDirective, MdbChipsModule };
//# sourceMappingURL=mdb-angular-ui-kit-chips.mjs.map
