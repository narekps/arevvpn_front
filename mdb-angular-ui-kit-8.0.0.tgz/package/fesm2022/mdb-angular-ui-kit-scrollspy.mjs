import * as i0 from '@angular/core';
import { HostListener, HostBinding, Input, Inject, Directive, Injectable, EventEmitter, PLATFORM_ID, Output, ContentChildren, Component, NgModule } from '@angular/core';
import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { takeUntil, distinctUntilChanged } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { coerceBooleanProperty } from '@angular/cdk/coercion';

class MdbScrollspyLinkDirective {
    cdRef;
    document;
    get scrollIntoView() {
        return this._scrollIntoView;
    }
    set scrollIntoView(value) {
        this._scrollIntoView = value;
    }
    _scrollIntoView = true;
    get section() {
        return this._section;
    }
    set section(value) {
        if (value) {
            this._section = value;
        }
    }
    _section;
    _id;
    constructor(cdRef, document) {
        this.cdRef = cdRef;
        this.document = document;
    }
    get id() {
        return this._id;
    }
    set id(newId) {
        if (newId) {
            this._id = newId;
        }
    }
    scrollspyLink = true;
    active = false;
    onClick() {
        if (this.section && this.scrollIntoView === true) {
            this.section.scrollIntoView();
        }
    }
    detectChanges() {
        this.cdRef.detectChanges();
    }
    assignSectionToId() {
        this.section = this.document.documentElement.querySelector(`#${this.id}`);
    }
    ngOnInit() {
        this.assignSectionToId();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyLinkDirective, deps: [{ token: i0.ChangeDetectorRef }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.1", type: MdbScrollspyLinkDirective, isStandalone: false, selector: "[mdbScrollspyLink]", inputs: { scrollIntoView: "scrollIntoView", id: ["mdbScrollspyLink", "id"] }, host: { listeners: { "click": "onClick()" }, properties: { "class.scrollspy-link": "this.scrollspyLink", "class.active": "this.active" } }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyLinkDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[mdbScrollspyLink]',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { scrollIntoView: [{
                type: Input
            }], id: [{
                type: Input,
                args: ['mdbScrollspyLink']
            }], scrollspyLink: [{
                type: HostBinding,
                args: ['class.scrollspy-link']
            }], active: [{
                type: HostBinding,
                args: ['class.active']
            }], onClick: [{
                type: HostListener,
                args: ['click', []]
            }] } });

class MdbScrollspyService {
    scrollSpys = [];
    activeSubject = new Subject();
    active$ = this.activeSubject;
    addScrollspy(scrollSpy) {
        this.scrollSpys.push(scrollSpy);
    }
    removeScrollspy(scrollSpyId) {
        const scrollSpyIndex = this.scrollSpys.findIndex((spy) => {
            return spy.id === scrollSpyId;
        });
        this.scrollSpys.splice(scrollSpyIndex, 1);
    }
    updateActiveState(scrollSpyId, activeLinkId) {
        const scrollSpy = this.scrollSpys.find((spy) => {
            return spy.id === scrollSpyId;
        });
        if (!scrollSpy) {
            return;
        }
        const activeLink = scrollSpy.links.find((link) => {
            return link.id === activeLinkId;
        });
        this.setActiveLink(activeLink);
    }
    removeActiveState(scrollSpyId, activeLinkId) {
        const scrollSpy = this.scrollSpys.find((spy) => {
            return spy.id === scrollSpyId;
        });
        if (!scrollSpy) {
            return;
        }
        const activeLink = scrollSpy.links.find((link) => {
            return link.id === activeLinkId;
        });
        if (!activeLink) {
            return;
        }
        activeLink.active = false;
        activeLink.detectChanges();
    }
    setActiveLink(activeLink) {
        if (activeLink) {
            activeLink.active = true;
            activeLink.detectChanges();
            this.activeSubject.next(activeLink);
        }
    }
    removeActiveLinks(scrollSpyId) {
        const scrollSpy = this.scrollSpys.find((spy) => {
            return spy.id === scrollSpyId;
        });
        if (!scrollSpy) {
            return;
        }
        scrollSpy.links.forEach((link) => {
            link.active = false;
            link.detectChanges();
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyService });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyService, decorators: [{
            type: Injectable
        }] });

// eslint-disable-next-line @angular-eslint/component-class-suffix
class MdbScrollspyDirective {
    scrollSpyService;
    _elementRef;
    _renderer;
    links;
    _destroy$ = new Subject();
    get id() {
        return this._id;
    }
    set id(newId) {
        if (newId) {
            this._id = newId;
        }
    }
    _id;
    get collapsible() {
        return this._collapsible;
    }
    set collapsible(value) {
        this._collapsible = coerceBooleanProperty(value);
    }
    _collapsible = false;
    _isBrowser;
    activeLinkChange = new EventEmitter();
    activeSub;
    constructor(scrollSpyService, _elementRef, _renderer, platformId) {
        this.scrollSpyService = scrollSpyService;
        this._elementRef = _elementRef;
        this._renderer = _renderer;
        this._isBrowser = isPlatformBrowser(platformId);
    }
    get host() {
        return this._elementRef.nativeElement;
    }
    collapsibleElementHeight = 0;
    ngOnInit() {
        if (this._isBrowser) {
            this.collapsibleElementHeight = this.host.getBoundingClientRect().height;
        }
        this.activeSub = this.scrollSpyService.active$
            .pipe(takeUntil(this._destroy$), distinctUntilChanged())
            .subscribe((activeLink) => {
            this.activeLinkChange.emit(activeLink);
            if (this.collapsible) {
                this.styleCollapsibleElement();
            }
        });
    }
    ngAfterContentInit() {
        this.scrollSpyService.addScrollspy({ id: this.id, links: this.links });
    }
    ngOnDestroy() {
        this.scrollSpyService.removeScrollspy(this.id);
        this._destroy$.next();
        this._destroy$.complete();
    }
    styleCollapsibleElement() {
        this._renderer.setStyle(this.host, 'overflow', 'hidden');
        this._renderer.setStyle(this.host, 'transition', 'height 0.2s ease-in-out');
        this._renderer.setStyle(this.host, 'flex-wrap', 'nowrap');
        const hostSiblings = this.getAllSiblings(this.host);
        const isAnySiblingActive = hostSiblings.some((element) => {
            return element.classList.contains('active');
        });
        if (this.collapsible && isAnySiblingActive) {
            this._renderer.setStyle(this.host, 'height', `${this.collapsibleElementHeight}px`);
        }
        else if (this.collapsible && !isAnySiblingActive) {
            this._renderer.setStyle(this.host, 'height', '0px');
        }
    }
    getAllSiblings(element) {
        let siblings = [];
        if (!element.parentNode) {
            return siblings;
        }
        let sibling = element.parentNode.firstElementChild;
        do {
            if (sibling != element) {
                siblings.push(sibling);
            }
        } while ((sibling = sibling.nextElementSibling));
        return siblings;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyDirective, deps: [{ token: MdbScrollspyService }, { token: i0.ElementRef }, { token: i0.Renderer2 }, { token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbScrollspyDirective, isStandalone: false, selector: "[mdbScrollspy]", inputs: { id: ["mdbScrollspy", "id"], collapsible: "collapsible" }, outputs: { activeLinkChange: "activeLinkChange" }, queries: [{ propertyName: "links", predicate: MdbScrollspyLinkDirective, descendants: true }], ngImport: i0, template: '<ng-content></ng-content>', isInline: true });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyDirective, decorators: [{
            type: Component,
            args: [{
                    // eslint-disable-next-line @angular-eslint/component-selector
                    selector: '[mdbScrollspy]',
                    template: '<ng-content></ng-content>',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: MdbScrollspyService }, { type: i0.ElementRef }, { type: i0.Renderer2 }, { type: Object, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { links: [{
                type: ContentChildren,
                args: [MdbScrollspyLinkDirective, { descendants: true }]
            }], id: [{
                type: Input,
                args: ['mdbScrollspy']
            }], collapsible: [{
                type: Input
            }], activeLinkChange: [{
                type: Output
            }] } });

// eslint-disable-next-line @angular-eslint/directive-class-suffix
class MdbScrollspyElementDirective {
    _elementRef;
    renderer;
    ngZone;
    scrollSpyService;
    _document;
    id;
    get host() {
        return this._elementRef.nativeElement;
    }
    container;
    get scrollSpyId() {
        return this._scrollSpyId;
    }
    set scrollSpyId(newId) {
        if (newId) {
            this._scrollSpyId = newId;
        }
    }
    _scrollSpyId;
    offset = 0;
    constructor(_elementRef, renderer, ngZone, scrollSpyService, _document) {
        this._elementRef = _elementRef;
        this.renderer = renderer;
        this.ngZone = ngZone;
        this.scrollSpyService = scrollSpyService;
        this._document = _document;
    }
    isElementInViewport() {
        const scrollTop = this.container.scrollTop;
        const elTop = this.host.offsetTop - this.offset;
        const elHeight = this.host.offsetHeight;
        return scrollTop >= elTop && scrollTop < elTop + elHeight;
    }
    updateActiveState(scrollSpyId, id) {
        if (this.isElementInViewport()) {
            this.scrollSpyService.removeActiveLinks(scrollSpyId);
            this.scrollSpyService.updateActiveState(scrollSpyId, id);
        }
    }
    onScroll() {
        this.updateActiveState(this.scrollSpyId, this.id);
    }
    listenToScroll() {
        this.renderer.listen(this.container, 'scroll', () => {
            this.onScroll();
        });
    }
    ngOnInit() {
        this.id = this.host.id;
        if (!this.container) {
            this.container = this._getClosestEl(this.host, '.scrollspy-container');
        }
        this.renderer.setStyle(this.container, 'position', 'relative');
        this.ngZone.runOutsideAngular(this.listenToScroll.bind(this));
    }
    ngAfterViewInit() {
        setTimeout(() => {
            this.updateActiveState(this.scrollSpyId, this.id);
        }, 0);
    }
    _getClosestEl(el, selector) {
        for (; el && el !== this._document; el = el.parentNode) {
            if (el.matches && el.matches(selector)) {
                return el;
            }
        }
        return null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyElementDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.NgZone }, { token: MdbScrollspyService }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.1", type: MdbScrollspyElementDirective, isStandalone: false, selector: "[mdbScrollspyElement]", inputs: { container: "container", scrollSpyId: ["mdbScrollspyElement", "scrollSpyId"], offset: "offset" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyElementDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[mdbScrollspyElement]',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.NgZone }, { type: MdbScrollspyService }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { container: [{
                type: Input
            }], scrollSpyId: [{
                type: Input,
                args: ['mdbScrollspyElement']
            }], offset: [{
                type: Input
            }] } });

class MdbScrollspyWindowDirective {
    document;
    el;
    renderer;
    ngZone;
    scrollSpyService;
    id;
    get scrollSpyId() {
        return this._scrollSpyId;
    }
    set scrollSpyId(newId) {
        if (newId) {
            this._scrollSpyId = newId;
        }
    }
    _scrollSpyId;
    offset = 0;
    constructor(document, el, renderer, ngZone, scrollSpyService) {
        this.document = document;
        this.el = el;
        this.renderer = renderer;
        this.ngZone = ngZone;
        this.scrollSpyService = scrollSpyService;
    }
    isElementInViewport() {
        const scrollTop = this.document.documentElement.scrollTop || this.document.body.scrollTop;
        const elHeight = this.el.nativeElement.offsetHeight;
        const elTop = this.el.nativeElement.offsetTop - this.offset;
        const elBottom = elTop + elHeight;
        return scrollTop >= elTop && scrollTop <= elBottom;
    }
    updateActiveState(scrollSpyId, id) {
        if (this.isElementInViewport()) {
            this.scrollSpyService.updateActiveState(scrollSpyId, id);
        }
        else {
            this.scrollSpyService.removeActiveState(scrollSpyId, id);
        }
    }
    onScroll() {
        this.updateActiveState(this.scrollSpyId, this.id);
    }
    listenToScroll() {
        this.renderer.listen(window, 'scroll', () => {
            this.onScroll();
        });
    }
    ngOnInit() {
        this.id = this.el.nativeElement.id;
        this.ngZone.runOutsideAngular(this.listenToScroll.bind(this));
    }
    ngAfterViewInit() {
        setTimeout(() => {
            this.updateActiveState(this.scrollSpyId, this.id);
        }, 0);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyWindowDirective, deps: [{ token: DOCUMENT }, { token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.NgZone }, { token: MdbScrollspyService }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.1", type: MdbScrollspyWindowDirective, isStandalone: false, selector: "[mdbScrollspyWindow]", inputs: { scrollSpyId: ["mdbScrollspyWindow", "scrollSpyId"], offset: "offset" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyWindowDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[mdbScrollspyWindow]',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.NgZone }, { type: MdbScrollspyService }], propDecorators: { scrollSpyId: [{
                type: Input,
                args: ['mdbScrollspyWindow']
            }], offset: [{
                type: Input
            }] } });

class MdbScrollspyModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyModule, declarations: [MdbScrollspyDirective,
            MdbScrollspyLinkDirective,
            MdbScrollspyElementDirective,
            MdbScrollspyWindowDirective], exports: [MdbScrollspyDirective,
            MdbScrollspyLinkDirective,
            MdbScrollspyElementDirective,
            MdbScrollspyWindowDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyModule, providers: [MdbScrollspyService] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbScrollspyModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        MdbScrollspyDirective,
                        MdbScrollspyLinkDirective,
                        MdbScrollspyElementDirective,
                        MdbScrollspyWindowDirective,
                    ],
                    exports: [
                        MdbScrollspyDirective,
                        MdbScrollspyLinkDirective,
                        MdbScrollspyElementDirective,
                        MdbScrollspyWindowDirective,
                    ],
                    providers: [MdbScrollspyService],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MdbScrollspyDirective, MdbScrollspyElementDirective, MdbScrollspyLinkDirective, MdbScrollspyModule, MdbScrollspyService, MdbScrollspyWindowDirective };
//# sourceMappingURL=mdb-angular-ui-kit-scrollspy.mjs.map
