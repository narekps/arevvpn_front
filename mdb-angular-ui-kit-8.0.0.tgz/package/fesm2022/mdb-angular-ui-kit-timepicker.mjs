import * as i0 from '@angular/core';
import { signal, HostListener, ViewChild, Inject, ChangeDetectionStrategy, ViewEncapsulation, Component, EventEmitter, booleanAttribute, Output, Input, InjectionToken, Directive, TemplateRef, ContentChild, forwardRef, NgModule } from '@angular/core';
import * as i1$1 from '@angular/cdk/overlay';
import { OverlayConfig, OverlayModule } from '@angular/cdk/overlay';
import * as i2$1 from '@angular/cdk/portal';
import { ComponentPortal, TemplatePortal, PortalModule } from '@angular/cdk/portal';
import { Subject, merge, fromEvent, takeUntil, switchMap, tap, raceWith, timer, take } from 'rxjs';
import { take as take$1, filter } from 'rxjs/operators';
import * as i2 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import { trigger, state, transition, style, animate } from '@angular/animations';
import * as i1 from '@angular/cdk/a11y';
import { A11yModule } from '@angular/cdk/a11y';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

class MdbTimepickerContentComponent {
    _cdRef;
    _ngZone;
    focusMonitor;
    elem;
    renderer;
    _document;
    plate;
    hand;
    focus;
    digitalMinute;
    container;
    hourUp;
    hourDown;
    minuteUp;
    minuteDown;
    handleKeyboardEvent(event) {
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            if (this._showHours) {
                this._arrowChangeHour(event.key);
            }
            else {
                this._arrowChangeMinute(event.key);
            }
        }
        else if (event.key === 'ArrowDown') {
            event.preventDefault();
            if (this._showHours) {
                this._arrowChangeHour(event.key);
            }
            else {
                this._arrowChangeMinute(event.key);
            }
        }
    }
    _hideAnimationDone = new Subject();
    _destroy$ = new Subject();
    _mouseUp$;
    _contentAnimationState = 'show';
    autoClose;
    options;
    maxTime;
    minTime;
    picker;
    increment;
    format12;
    format24;
    value;
    inline;
    showClearBtn;
    _isInlineHourButtonHovered = signal(false);
    _isInlineMinutButtoneHovered = signal(false);
    switchHoursToMinutesOnClick;
    _maxTime;
    _minTime;
    _returnHours;
    _disabledHours = [];
    _disabledMinutes = [];
    _isMouseDown = false;
    _hoursTicks = [];
    _innerHoursTicks = [];
    _minuteDigitalDisabled = false;
    _minutesTicks = [];
    _okButtonDisabled = false;
    _selectedTime;
    _showHours = true;
    _radius = {
        dial: 130,
        inner: 80,
        outer: 110,
        tick: 16,
    };
    _denominator = {
        1: 30,
        5: 6,
        10: 3,
        15: 2,
        20: 1.5,
        // 30: 1,
        // 60: 0.5
    };
    touchSupported = 'ontouchstart' in window;
    constructor(_cdRef, _ngZone, focusMonitor, elem, renderer, _document) {
        this._cdRef = _cdRef;
        this._ngZone = _ngZone;
        this.focusMonitor = focusMonitor;
        this.elem = elem;
        this.renderer = renderer;
        this._document = _document;
    }
    ngOnInit() {
        this._maxTime = this.maxTime;
        this._minTime = this.minTime;
        this._selectedTime = this.value;
        const { ampm } = this._selectedTime;
        // Add disabled hours to array for PM and AM Hours
        if (this.format12 && !this.format24) {
            this._selectedTime.ampm = ampm === 'PM' ? 'AM' : 'PM';
            this._generateTicks();
            this._selectedTime.ampm = this._selectedTime.ampm === 'PM' ? 'AM' : 'PM';
        }
        this._generateTicks();
        this._setOkBtnDisabled();
        this._setMinuteDigitalDisabled();
    }
    ngAfterViewInit() {
        this._checkDraw();
        setTimeout(() => {
            this.focusMonitor.focusVia(this.focus, 'keyboard');
            this.container.nativeElement.focus();
        }, 0);
        if (this.inline) {
            this._setupArrowButtons();
            return;
        }
        ['mousedown', 'mouseup', 'touchend', 'touchstart'].forEach((event) => {
            this.renderer.listen(this.plate.nativeElement, event, (ev) => {
                if (event === 'mousedown' || event === 'touchstart') {
                    this._mousedown(ev, false);
                }
            });
        });
    }
    ngOnDestroy() {
        this._hideAnimationDone.complete();
        this._destroy$.next();
        this._destroy$.complete();
    }
    markForCheck() {
        this._cdRef.markForCheck();
    }
    _onAnimationDone(event) {
        if (event.toState === 'hide') {
            this._hideAnimationDone.next();
        }
    }
    _startHideAnimation() {
        this._contentAnimationState = 'hide';
        this._cdRef.markForCheck();
    }
    _checkDraw() {
        const { h, m } = this._selectedTime;
        const value = this._showHours ? parseInt(h, 0) : parseInt(m, 0);
        const unit = Math.PI / (this._showHours ? 6 : 30);
        const radian = value * unit;
        const radius = this._showHours && value > 0 && value < 13 ? this._radius.outer : this._radius.inner;
        const xd = Math.sin(radian) * radius;
        const yd = -Math.cos(radian) * radius;
        if (this.inline) {
            return;
        }
        this.setClockHand(xd, yd);
    }
    _mousedown(e, space) {
        this._isMouseDown = true;
        const offset = this.plate.nativeElement.getBoundingClientRect();
        const isTouch = /^touch/.test(e.type);
        const x0 = offset.left + this._radius.dial;
        const y0 = offset.top + this._radius.dial;
        const dx = (isTouch ? e.touches[0] : e).clientX - x0;
        const dy = (isTouch ? e.touches[0] : e).clientY - y0;
        const z = Math.sqrt(dx * dx + dy * dy);
        let moved = false;
        if (space &&
            (z < this._radius.outer - this._radius.tick || z > this._radius.outer + this._radius.tick)) {
            return;
        }
        e.preventDefault();
        e.stopPropagation();
        if (this._showHours) {
            this.setClockHand(dx, dy);
        }
        else {
            this.setClockHand(dx, dy, this.increment);
        }
        const mousemoveEventMethod = (event) => {
            if (!this.touchSupported) {
                event.preventDefault();
            }
            event.stopPropagation();
            const isTouch = /^touch/.test(event.type);
            const x = (isTouch ? event.touches[0] : event).clientX - x0;
            const y = (isTouch ? event.touches[0] : event).clientY - y0;
            if (!moved && x === dx && y === dy) {
                return;
            }
            moved = true;
            this._ngZone.run(() => {
                this.setClockHand(x, y, this.increment);
            });
        };
        const mouseupEventMethod = (event) => {
            this._document.removeEventListener('mousemove', mousemoveEventMethod);
            if (this.touchSupported) {
                this._document.removeEventListener('touchmove', mousemoveEventMethod);
            }
            if (!this.touchSupported) {
                event.preventDefault();
            }
            const x = event.clientX - x0;
            const y = event.clientY - y0;
            if ((space || moved) && x === dx && y === dy) {
                this.setClockHand(x, y);
            }
            this._ngZone.run(() => {
                if (this.autoClose && !this._showHours) {
                    this._okBtnClicked();
                }
            });
            this._showMinutesClock();
            this.digitalMinute.nativeElement.focus();
            this._isMouseDown = false;
            this._document.removeEventListener('mouseup', mouseupEventMethod);
            if (this.touchSupported) {
                this._document.removeEventListener('touchend', mouseupEventMethod);
            }
            this.picker._emitTimeChangeEvent(this._selectedTime);
        };
        this._document.addEventListener('mousemove', mousemoveEventMethod);
        if (this.touchSupported) {
            this._document.addEventListener('touchmove', mousemoveEventMethod);
        }
        this._document.addEventListener('mouseup', mouseupEventMethod);
        if (this.touchSupported) {
            this._document.addEventListener('touchend', mouseupEventMethod);
        }
    }
    _closeBtnClicked() {
        // todo this.isOpen = false;
        const { ampm, h, m } = this._selectedTime;
        this._returnHours = this.format12 && !this.format24 ? `${h}:${m}${ampm}` : `${h}:${m}${ampm}`;
        this.picker.close();
    }
    _clearBtnClicked() {
        this._setAmPm('AM');
        this._setHour(12);
        this._setMinute(0);
        this._generateTicks();
        this._showHoursClock();
        this.picker._setValue('');
        this.picker._selectionChange$.next('');
        this.picker.clear.emit();
    }
    _okBtnClicked() {
        if (!this._okButtonDisabled) {
            const { ampm, h, m } = this._selectedTime;
            this._returnHours =
                this.format12 && !this.format24 ? `${h}:${m} ${ampm}` : `${h}:${m} ${ampm}`;
            this.renderer.addClass(this.picker.input, 'active');
            this.picker._selectionChange$.next(this.format12 && !this.format24 ? `${h}:${m} ${ampm}` : `${h}:${m}`);
            this.picker._setValue(this._returnHours);
            this.picker.onChangeCb(this._returnHours);
            this.picker.close();
        }
    }
    _arrowChangeHour(key) {
        const { h, ampm } = this._to24(this._selectedTime);
        const selectedHour = Number(h);
        const availableHours = [];
        this._disabledHours.map((hour, index) => !hour && availableHours.push(index));
        let toChange;
        let value = key === 'ArrowUp'
            ? availableHours.indexOf(selectedHour) + 1
            : availableHours.indexOf(selectedHour) - 1;
        value = value < 0 ? availableHours.length - 1 : value;
        value = value > availableHours.length - 1 ? 0 : value;
        toChange = availableHours[value];
        if (this.format12 && !this.format24) {
            if (toChange >= 12) {
                toChange = toChange - 12;
                if (ampm === 'AM') {
                    this._setAmPm('PM');
                }
            }
            else if (toChange <= 0 || toChange < 12) {
                if (ampm === 'PM') {
                    this._setAmPm('AM');
                }
            }
        }
        this._showHoursClock();
        this._setHour(toChange);
        this._checkDraw();
    }
    _arrowChangeMinute(key) {
        if (!this._minuteDigitalDisabled) {
            if (this._showHours) {
                this._showMinutesClock();
            }
            const { m } = this._selectedTime;
            const availableMinutes = [];
            this._generateMinutesDisable();
            this._disabledMinutes.map((disabled, i) => {
                if (!disabled) {
                    availableMinutes.push(i);
                }
            });
            let toChange;
            let value = key === 'ArrowUp'
                ? availableMinutes.indexOf(Number(m)) + 1
                : availableMinutes.indexOf(Number(m)) - 1;
            value = value < 0 ? availableMinutes.length - 1 : value;
            value = value > availableMinutes.length - 1 ? 0 : value;
            toChange = availableMinutes[value];
            this._setMinute(toChange);
            this._checkDraw();
        }
    }
    _generateMinutesDisable() {
        const rounding = this.increment ? 5 : 1;
        for (let i = 0; i < 60; i++) {
            const disableByRounding = rounding > 1 && i % rounding !== 0;
            const disabled = this._rangeMinute(i, 'min') || this._rangeMinute(i, 'max') || disableByRounding;
            this._disabledMinutes[i] = disabled;
        }
    }
    _setHour(hour) {
        if (Number(this._selectedTime.h) !== hour) {
            if (this.format12 && !this.format24) {
                hour = hour <= 0 ? 12 : hour;
                hour = hour > 12 ? 1 : hour;
            }
            else {
                hour = hour >= 24 ? 0 : hour;
                hour = hour <= -1 ? 23 : hour;
            }
            this._selectedTime.h = hour >= 10 ? `${hour}` : `0${hour}`;
            this._setMinuteDigitalDisabled();
        }
    }
    _setMinute(min) {
        if (Number(this._selectedTime.m) !== min) {
            min = min >= 60 ? 0 : min;
            min = min <= -1 ? 59 : min;
            this._selectedTime.m = min >= 10 ? `${min}` : `0${min}`;
            this._setOkBtnDisabled();
        }
    }
    _setAmPm(ampm) {
        this._selectedTime.ampm = ampm;
        this._generateTicks();
        this._setOkBtnDisabled();
        this._setMinuteDigitalDisabled();
        this._checkDraw();
        this.picker._emitTimeChangeEvent(this._selectedTime);
    }
    _showHoursClock() {
        this._generateTicks();
        this._showHours = true;
        this._setOkBtnDisabled();
        this._checkDraw();
    }
    _showMinutesClock() {
        if (!this.switchHoursToMinutesOnClick) {
            return;
        }
        if (!this._minuteDigitalDisabled) {
            this._showHours = false;
            this._generateTicks();
            this._setOkBtnDisabled();
            this._generateMinutesDisable();
            if (this._disabledMinutes[Number(this._selectedTime.m)] === true) {
                this._setMinute(this._disabledMinutes.indexOf(false));
            }
            this._checkDraw();
        }
    }
    _generateTicks() {
        this._generateHoursTicks();
        this._generateMinutesTicks();
        if (this.format24) {
            this._generateInnerHoursTicks();
        }
    }
    _generateHoursTicks() {
        this._hoursTicks = [];
        // Calculations taken from STANDARD library
        const hours = ['12', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11'];
        const elements = 360 / hours.length;
        const rad = (element) => element * (Math.PI / 180);
        const clockWidth = this._radius.dial - this._radius.tick;
        const clockHeight = this._radius.dial - this._radius.tick;
        const radius = clockWidth - 4;
        hours.forEach((element, i) => {
            const angle = rad(i * elements);
            const tick = {
                time: element,
                left: clockWidth + Math.sin(angle) * radius,
                bottom: clockHeight + Math.cos(angle) * radius,
                disabled: this._rangeHour(Number(element), 'min') || this._rangeHour(Number(element), 'max'),
            };
            this._hoursTicks.push(tick);
        });
    }
    _generateInnerHoursTicks() {
        this._innerHoursTicks = [];
        // Calculations taken from STANDARD library
        const innerHours = ['00', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23'];
        const elements = 360 / innerHours.length;
        const rad = (element) => element * (Math.PI / 180);
        const clockWidth = this._radius.inner - this._radius.tick;
        const clockHeight = this._radius.inner - this._radius.tick;
        const radius = clockWidth - 4;
        innerHours.forEach((element, i) => {
            const angle = rad(i * elements);
            const tick = {
                time: element,
                left: clockWidth + Math.sin(angle) * radius,
                bottom: clockHeight + Math.cos(angle) * radius,
                disabled: this._rangeHour(Number(element), 'min') || this._rangeHour(Number(element), 'max'),
            };
            this._innerHoursTicks.push(tick);
        });
    }
    _generateMinutesTicks() {
        this._minutesTicks = [];
        // Calculations taken from STANDARD library
        const minutes = ['00', '05', '10', '15', '20', '25', '30', '35', '40', '45', '50', '55'];
        const elements = 360 / minutes.length;
        const rad = (element) => element * (Math.PI / 180);
        const clockWidth = this._radius.dial - this._radius.tick;
        const clockHeight = this._radius.dial - this._radius.tick;
        const radius = clockWidth - 4;
        const rounding = this.increment ? 5 : 1;
        minutes.forEach((element, i) => {
            const angle = rad(i * elements);
            const disableByRounding = rounding > 1 && Number(element) % rounding !== 0;
            const tick = {
                time: element,
                left: clockWidth + Math.sin(angle) * radius,
                bottom: clockHeight + Math.cos(angle) * radius,
                disabled: this._rangeMinute(Number(element), 'min') ||
                    this._rangeMinute(Number(element), 'max') ||
                    disableByRounding,
            };
            this._minutesTicks.push(tick);
        });
    }
    setClockHand(x, y, roundBy) {
        const rounding = roundBy ? 5 : 1;
        let radian = Math.atan2(x, -y);
        const isHours = this._showHours;
        const unit = Math.PI / (isHours ? 6 : rounding ? this._denominator[rounding] : 30);
        const z = Math.sqrt(x * x + y * y);
        const inner = isHours && z > (this._radius.outer + this._radius.inner) / 2;
        let value = this._showHours
            ? parseInt(this._selectedTime.h, 0)
            : parseInt(this._selectedTime.m, 0);
        const radius = inner && (!this.format12 || this.format24) ? this._radius.inner : this._radius.outer;
        if (radian < 0) {
            radian = Math.PI * 2 + radian;
        }
        value = Math.round(radian / unit);
        radian = value * unit;
        if (this.format12 && !this.format24 && isHours) {
            if (value === 0) {
                value = 12;
            }
            if (this._isMouseDown) {
                if (isHours && (this._rangeHour(value, 'min') || this._rangeHour(value, 'max'))) {
                    return;
                }
            }
        }
        else if ((!this.format12 || this.format24) && isHours) {
            value = !inner ? value + 12 : value;
            value = value === 24 ? 0 : value;
            value = inner && value === 0 ? 12 : value;
            value = !inner && value === 12 ? 0 : value;
            if (this._isMouseDown) {
                if (isHours && (this._rangeHour(value, 'min') || this._rangeHour(value, 'max'))) {
                    return;
                }
            }
        }
        else {
            if (rounding) {
                value *= rounding;
            }
            if (value === 60) {
                value = 0;
            }
        }
        if (!isHours) {
            if (this._rangeMinute(value, 'min') || this._rangeMinute(value, 'max')) {
                this._cdRef.markForCheck();
                return;
            }
        }
        const rotationDegree = radian * (180 / Math.PI);
        const isOnInnerClock = Number(this._selectedTime.h) > 12 || Number(this._selectedTime.h) === 0;
        const clockHandHeight = isOnInnerClock && this._showHours ? '21.5%' : 'calc(40% + 1px)';
        this.renderer.setStyle(this.hand.nativeElement, 'transform', `rotateZ(${rotationDegree}deg)`);
        this.renderer.setStyle(this.hand.nativeElement, 'height', clockHandHeight);
        if (this._showHours) {
            if (value !== Number(this._selectedTime.h)) {
                this._setHour(value);
                this._setMinuteDigitalDisabled();
            }
        }
        else {
            if (value !== Number(this._selectedTime.m)) {
                this._setMinute(value);
            }
        }
        this._cdRef.markForCheck();
    }
    _to24(time) {
        let hour = time.ampm === 'PM' ? Number(time.h) + 12 : Number(time.h);
        if (this.format12 && !this.format24) {
            hour = hour === 12 ? 0 : hour;
        }
        hour = hour === 24 ? 12 : hour;
        return {
            ...time,
            h: `${hour}`,
        };
    }
    _rangeHour(index, range) {
        let status = false;
        const i = Number(this._to24({ ...this._selectedTime, h: `${index}` }).h);
        if (!this.format12 || this.format24) {
            const minH = this.minTime && Number(this._minTime.h);
            const maxH = this.maxTime && Number(this._maxTime.h);
            if (range === 'min' && this.minTime) {
                status = index < minH;
                if (status && this._maxTime && this._maxTime.h < this._minTime.h) {
                    status = false;
                }
            }
            else if (range === 'max' && this.maxTime) {
                status = index > maxH;
                if (status && this._minTime && this._minTime.h > this._maxTime.h && minH <= index) {
                    status = false;
                }
            }
        }
        else {
            const min = this._minTime && Number(this._to24(this._minTime).h);
            const max = this._maxTime && Number(this._to24(this._maxTime).h);
            if (range === 'min' && this.minTime) {
                status = i < min;
            }
            if (range === 'max' && this.maxTime) {
                status = i > max;
            }
            if (min > max) {
                status = false;
                status = min > i && i > max;
            }
        }
        this._disabledHours[i] = status;
        return status;
    }
    _rangeMinute(index, range) {
        let status = false;
        if (!this._showHours) {
            if (range === 'min' && this.minTime) {
                const isSameHour = this._minTime.h === this._selectedTime.h;
                const value = index < Number(this._minTime.m);
                status = value && isSameHour;
            }
            else if (range === 'max' && this.maxTime) {
                const isSameHour = this._maxTime.h === this._selectedTime.h;
                const value = index > Number(this._maxTime.m);
                status = value && isSameHour;
            }
        }
        if (this.format12 && !this.format24) {
            const min = this._minTime && Number(this._to24(this._minTime).h);
            const max = this._maxTime && Number(this._to24(this._maxTime).h);
            const i = Number(this._to24(this._selectedTime).h);
            if (range === 'min' && min) {
                status = i === min && index < Number(this._minTime.m);
            }
            else if (range === 'max' && max) {
                status = i === max && index > Number(this._maxTime.m);
            }
            status = status || this._disabledHours[i];
        }
        return status;
    }
    _setOkBtnDisabled() {
        const hour = Number(this._to24(this._selectedTime).h);
        this._okButtonDisabled = this._disabledHours[hour];
        if (!this._okButtonDisabled) {
            if (this._minTime &&
                this._selectedTime.h === this._minTime.h &&
                this._selectedTime.ampm === this._minTime.ampm) {
                this._okButtonDisabled = this._selectedTime.m < this._minTime.m;
            }
            if (this._maxTime &&
                this._selectedTime.h === this._maxTime.h &&
                this._selectedTime.ampm === this._maxTime.ampm) {
                this._okButtonDisabled = this._selectedTime.m > this._maxTime.m;
            }
        }
    }
    _setMinuteDigitalDisabled() {
        const { h } = this._to24(this._selectedTime);
        this._minuteDigitalDisabled = this._disabledHours[Number(h)];
    }
    _setupButtonEvents(button, changeFn) {
        const buttonElement = button.nativeElement;
        const down$ = merge(fromEvent(buttonElement, 'mousedown', { passive: false }), fromEvent(buttonElement, 'touchstart', { passive: false }));
        const up$ = merge(this._mouseUp$, fromEvent(buttonElement, 'touchend', { passive: false }));
        const HOLD_TIME = 500; // Time to trigger hold state
        const INTERVAL = 100; // Interval between hold events
        // Disable dragAndDrop behaviour for the button. Drag action initiated by the browser
        // interferes with the normal detection of the mouseup event which causes problems with
        // not ending the hold state when the mouse was released inside the button and mouseleave
        // event was not fired.
        buttonElement.ondragstart = () => false;
        down$
            .pipe(takeUntil(this._destroy$), switchMap(() => up$.pipe(
        // Handle click and quick touch
        tap((event) => {
            event.preventDefault(); // Prevent MouseEvent from being sent on TouchEvent
            changeFn();
            this.markForCheck();
        }), raceWith(timer(HOLD_TIME, INTERVAL).pipe(takeUntil(up$), 
        // Handle mouse hold and long touch
        tap(() => {
            changeFn();
            this.markForCheck();
        }))))))
            .subscribe();
    }
    _setupArrowButtons() {
        (this._mouseUp$ = fromEvent(document, 'mouseup', { passive: false }).pipe(take(1))),
            this._setupButtonEvents(this.hourUp, () => this._arrowChangeHour('ArrowUp'));
        this._setupButtonEvents(this.hourDown, () => this._arrowChangeHour('ArrowDown'));
        this._setupButtonEvents(this.minuteUp, () => this._arrowChangeMinute('ArrowUp'));
        this._setupButtonEvents(this.minuteDown, () => this._arrowChangeMinute('ArrowDown'));
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerContentComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.NgZone }, { token: i1.FocusMonitor }, { token: i0.ElementRef }, { token: i0.Renderer2 }, { token: DOCUMENT }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "19.2.1", type: MdbTimepickerContentComponent, isStandalone: false, selector: "mdb-timepicker-content", host: { listeners: { "keydown": "handleKeyboardEvent($event)" } }, viewQueries: [{ propertyName: "plate", first: true, predicate: ["plate"], descendants: true }, { propertyName: "hand", first: true, predicate: ["hand"], descendants: true }, { propertyName: "focus", first: true, predicate: ["focus"], descendants: true }, { propertyName: "digitalMinute", first: true, predicate: ["digitalMinute"], descendants: true }, { propertyName: "container", first: true, predicate: ["container"], descendants: true }, { propertyName: "hourUp", first: true, predicate: ["hourUp"], descendants: true }, { propertyName: "hourDown", first: true, predicate: ["hourDown"], descendants: true }, { propertyName: "minuteUp", first: true, predicate: ["minuteUp"], descendants: true }, { propertyName: "minuteDown", first: true, predicate: ["minuteDown"], descendants: true }], ngImport: i0, template: "@if(!inline){\n<div\n  #container\n  class=\"timepicker-container d-flex flex-column align-items-center justify-content-center\"\n  [@fadeInOutTimepicker]=\"_contentAnimationState\"\n  (@fadeInOutTimepicker.done)=\"_onAnimationDone($event)\"\n  cdkTrapFocus\n  tabindex=\"-1\"\n  [style.height.px]=\"461\"\n>\n  <div class=\"timepicker-elements d-flex flex-column justify-content-around\">\n    <div\n      class=\"timepicker-head d-flex flex-row align-items-center justify-content-center\"\n      [style.padding-right.px]=\"format24 ? 50 : 0\"\n    >\n      <div class=\"timepicker-head-content d-flex w-100 justify-content-evenly\">\n        <div class=\"timepicker-current-wrapper\">\n          <span\n            (click)=\"_showHoursClock()\"\n            (keydown.enter)=\"_showHoursClock()\"\n            class=\"position-relative h-100\"\n            #focus\n          >\n            <button\n              type=\"button\"\n              class=\"timepicker-current timepicker-hour\"\n              tabindex=\"0\"\n              [ngClass]=\"{active: _showHours}\"\n              [ngStyle]=\"{pointerEvents: _showHours ? 'none' : ''}\"\n            >\n              {{ _selectedTime.h }}\n            </button>\n          </span>\n          <button type=\"button\" class=\"timepicker-dot\" disabled>:</button>\n          <span\n            #digitalMinute\n            class=\"position-relative h-100\"\n            (click)=\"_showMinutesClock()\"\n            (keydown.enter)=\"_showMinutesClock()\"\n            [ngClass]=\"{'disabled': _minuteDigitalDisabled }\"\n          >\n            <button\n              type=\"button\"\n              class=\"timepicker-current timepicker-minute\"\n              tabindex=\"0\"\n              [ngClass]=\"{active: !_showHours}\"\n              [ngStyle]=\"{pointerEvents: _showHours ? '' : 'none'}\"\n            >\n              {{ _selectedTime.m }}\n            </button>\n          </span>\n        </div>\n        @if(format12 && !format24){\n        <div class=\"timepicker-mode-wrapper d-flex flex-column justify-content-center\">\n          <button\n            type=\"button\"\n            class=\"timepicker-hour-mode timepicker-am\"\n            (click)=\"_setAmPm('AM')\"\n            (keydown.enter)=\"_setAmPm('AM')\"\n            tabindex=\"0\"\n            [ngClass]=\"{ active: _selectedTime.ampm === 'AM'}\"\n          >\n            {{options.amLabel}}\n          </button>\n          <button\n            class=\"timepicker-hour-mode timepicker-pm\"\n            tabindex=\"0\"\n            [ngClass]=\"{ active: _selectedTime.ampm === 'PM'}\"\n            (click)=\"_setAmPm('PM')\"\n            (keydown.enter)=\"_setAmPm('PM')\"\n          >\n            {{options.pmLabel}}\n          </button>\n        </div>\n        }\n      </div>\n    </div>\n    <div\n      class=\"timepicker-clock-wrapper d-flex justify-content-center flex-column align-items-center\"\n    >\n      <div class=\"timepicker-clock\" #plate>\n        <span class=\"timepicker-middle-dot position-absolute\"></span>\n        <div class=\"timepicker-hand-pointer position-absolute\" #hand>\n          <div class=\"timepicker-circle position-absolute\"></div>\n        </div>\n        @if(_showHours){ @if(format24){\n        <div class=\"timepicker-clock-inner\">\n          @for(tick of _innerHoursTicks; track $index){\n          <span\n            class=\"timepicker-time-tips-inner\"\n            [ngClass]=\"{ disabled: tick.disabled, 'active': tick.time === _selectedTime.h || 0 + tick.time === _selectedTime.h}\"\n            [ngStyle]=\"{ left: tick.left + 'px', bottom: tick.bottom + 'px' }\"\n          >\n            <span class=\"timepicker-tips-inner-element\">{{ tick.time }}</span>\n          </span>\n          }\n        </div>\n        } @for (tick of _hoursTicks; track $index) {\n        <span\n          class=\"timepicker-time-tips-hours\"\n          [ngClass]=\"{ disabled: tick.disabled, 'active': tick.time === _selectedTime.h || 0 + tick.time === _selectedTime.h}\"\n          [ngStyle]=\"{ left: tick.left + 'px', bottom: tick.bottom + 'px' }\"\n          ><span class=\"timepicker-tips-element\">{{ tick.time }}</span></span\n        >\n        } } @else{ @for (tick of _minutesTicks; track $index) {\n        <span\n          class=\"timepicker-time-tips-minutes\"\n          [ngClass]=\"{ disabled: tick.disabled, 'active': tick.time === _selectedTime.m }\"\n          [ngStyle]=\"{ left: tick.left + 'px', bottom: tick.bottom + 'px' }\"\n        >\n          <span class=\"timepicker-tips-element\">{{ tick.time }}</span>\n        </span>\n        } }\n      </div>\n    </div>\n  </div>\n  <div class=\"timepicker-footer\">\n    <div class=\"d-flex justify-content-between w-100\">\n      @if(showClearBtn) {\n      <button\n        type=\"button\"\n        class=\"timepicker-button timepicker-clear\"\n        (click)=\"_clearBtnClicked()\"\n        tabindex=\"0\"\n      >\n        {{ options.clearLabel }}\n      </button>\n      }\n      <button\n        type=\"button\"\n        class=\"timepicker-button timepicker-cancel\"\n        (click)=\"_closeBtnClicked()\"\n        tabindex=\"0\"\n      >\n        {{ options.cancelLabel }}\n      </button>\n      <button\n        type=\"button\"\n        class=\"timepicker-button timepicker-submit\"\n        (click)=\"_okBtnClicked()\"\n        [ngClass]=\"{ disabled: _okButtonDisabled }\"\n        tabindex=\"0\"\n      >\n        {{ options.okLabel }}\n      </button>\n    </div>\n  </div>\n</div>\n} @else {\n<div\n  class=\"timepicker-container d-flex flex-column align-items-center justify-content-center\"\n  #container\n  [@fadeInOutTimepicker]=\"_contentAnimationState\"\n  (@fadeInOutTimepicker.done)=\"_onAnimationDone($event)\"\n  cdkTrapFocus\n  tabindex=\"-1\"\n>\n  <div\n    class=\"timepicker-elements timepicker-elements-inline d-flex flex-column justify-content-around\"\n  >\n    <div\n      class=\"timepicker-head timepicker-head-inline d-flex flex-row align-items-center justify-content-center\"\n    >\n      <div class=\"timepicker-head-content d-flex w-100 justify-content-evenly align-items-center\">\n        <div class=\"timepicker-current-wrapper\">\n          <span\n            #focus\n            class=\"timepicker-inline-hour-icons position-relative h-100\"\n            (click)=\"_showHoursClock()\"\n            (keydown.enter)=\"_showHoursClock()\"\n          >\n            <i\n              #hourUp\n              class=\"timepicker-icon-up timepicker-icon-inline-hour fas fa-chevron-up position-absolute text-white\"\n              [ngClass]=\"{ 'active': _isInlineHourButtonHovered() }\"\n            ></i>\n            <button\n              type=\"button\"\n              class=\"timepicker-current timepicker-current-inline timepicker-hour\"\n              tabindex=\"0\"\n              [ngClass]=\"{ active: _showHours }\"\n              (mouseover)=\"_isInlineHourButtonHovered.set(true)\"\n              (mouseleave)=\"_isInlineHourButtonHovered.set(false)\"\n            >\n              {{ _selectedTime.h }}\n            </button>\n            <i\n              #hourDown\n              class=\"timepicker-icon-down timepicker-icon-inline-hour fas fa-chevron-down position-absolute text-white\"\n              [ngClass]=\"{ 'active': _isInlineHourButtonHovered() }\"\n            ></i>\n          </span>\n          <button type=\"button\" class=\"timepicker-dot timepicker-current-inline\" disabled>:</button>\n          <span\n            #digitalMinute\n            class=\"timepicker-inline-minutes-icons position-relative h-100\"\n            [ngClass]=\"{'disabled': _minuteDigitalDisabled}\"\n            (click)=\"_showMinutesClock()\"\n            (keydown.enter)=\"_showMinutesClock()\"\n          >\n            <i\n              #minuteUp\n              class=\"timepicker-icon-up timepicker-icon-inline-minute fas fa-chevron-up position-absolute text-white\"\n              [ngClass]=\"{ 'active': _isInlineMinutButtoneHovered() }\"\n            ></i>\n            <button\n              type=\"button\"\n              class=\"timepicker-current timepicker-current-inline timepicker-minute\"\n              tabindex=\"0\"\n              [ngClass]=\"{ active: !_showHours }\"\n              (mouseover)=\"_isInlineMinutButtoneHovered.set(true)\"\n              (mouseleave)=\"_isInlineMinutButtoneHovered.set(false)\"\n            >\n              {{ _selectedTime.m }}\n            </button>\n            <i\n              #minuteDown\n              class=\"timepicker-icon-down timepicker-icon-inline-minute fas fa-chevron-down position-absolute text-white\"\n              [ngClass]=\"{ 'active': _isInlineMinutButtoneHovered() }\"\n            ></i>\n          </span>\n        </div>\n        <div class=\"timepicker-mode-wrapper d-flex justify-content-center\">\n          @if(format12 && !format24){\n          <button\n            type=\"button\"\n            class=\"timepicker-hour-mode timepicker-am me-2 ms-4\"\n            tabindex=\"0\"\n            (click)=\"_setAmPm('AM')\"\n            (keydown.enter)=\"_setAmPm('AM')\"\n            [ngClass]=\"{ active: _selectedTime.ampm === 'AM'}\"\n          >\n            {{options.amLabel}}\n          </button>\n          <button\n            class=\"timepicker-hour-mode timepicker-pm\"\n            (click)=\"_setAmPm('PM')\"\n            (keydown.enter)=\"_setAmPm('PM')\"\n            [ngClass]=\"{ active: _selectedTime.ampm === 'PM' }\"\n            tabindex=\"0\"\n          >\n            {{options.pmLabel}}\n          </button>\n          }\n          <button\n            type=\"button\"\n            class=\"timepicker-button timepicker-submit timepicker-submit-inline py-1 px-2 mb-0\"\n            tabindex=\"0\"\n            (click)=\"_okBtnClicked()\"\n            [ngClass]=\"{ disabled: _okButtonDisabled }\"\n          >\n            {{ options.okLabel }}\n          </button>\n        </div>\n        @if(!format12 && format24){\n        <button\n          class=\"timepicker-button timepicker-submit timepicker-submit-inline py-1 px-2 mb-0\"\n          tabindex=\"0\"\n        >\n          {{ options.okLabel }}\n        </button>\n        }\n      </div>\n    </div>\n  </div>\n</div>\n}\n", dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }, { kind: "directive", type: i1.CdkTrapFocus, selector: "[cdkTrapFocus]", inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"], exportAs: ["cdkTrapFocus"] }], animations: [
            trigger('fadeInOutTimepicker', [
                state('void', style({ opacity: 0 })),
                state('hide', style({ opacity: 0 })),
                state('show', style({ opacity: 1 })),
                transition('* <=> *', animate('300ms ease-in-out')),
            ]),
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerContentComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-timepicker-content', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, animations: [
                        trigger('fadeInOutTimepicker', [
                            state('void', style({ opacity: 0 })),
                            state('hide', style({ opacity: 0 })),
                            state('show', style({ opacity: 1 })),
                            transition('* <=> *', animate('300ms ease-in-out')),
                        ]),
                    ], standalone: false, template: "@if(!inline){\n<div\n  #container\n  class=\"timepicker-container d-flex flex-column align-items-center justify-content-center\"\n  [@fadeInOutTimepicker]=\"_contentAnimationState\"\n  (@fadeInOutTimepicker.done)=\"_onAnimationDone($event)\"\n  cdkTrapFocus\n  tabindex=\"-1\"\n  [style.height.px]=\"461\"\n>\n  <div class=\"timepicker-elements d-flex flex-column justify-content-around\">\n    <div\n      class=\"timepicker-head d-flex flex-row align-items-center justify-content-center\"\n      [style.padding-right.px]=\"format24 ? 50 : 0\"\n    >\n      <div class=\"timepicker-head-content d-flex w-100 justify-content-evenly\">\n        <div class=\"timepicker-current-wrapper\">\n          <span\n            (click)=\"_showHoursClock()\"\n            (keydown.enter)=\"_showHoursClock()\"\n            class=\"position-relative h-100\"\n            #focus\n          >\n            <button\n              type=\"button\"\n              class=\"timepicker-current timepicker-hour\"\n              tabindex=\"0\"\n              [ngClass]=\"{active: _showHours}\"\n              [ngStyle]=\"{pointerEvents: _showHours ? 'none' : ''}\"\n            >\n              {{ _selectedTime.h }}\n            </button>\n          </span>\n          <button type=\"button\" class=\"timepicker-dot\" disabled>:</button>\n          <span\n            #digitalMinute\n            class=\"position-relative h-100\"\n            (click)=\"_showMinutesClock()\"\n            (keydown.enter)=\"_showMinutesClock()\"\n            [ngClass]=\"{'disabled': _minuteDigitalDisabled }\"\n          >\n            <button\n              type=\"button\"\n              class=\"timepicker-current timepicker-minute\"\n              tabindex=\"0\"\n              [ngClass]=\"{active: !_showHours}\"\n              [ngStyle]=\"{pointerEvents: _showHours ? '' : 'none'}\"\n            >\n              {{ _selectedTime.m }}\n            </button>\n          </span>\n        </div>\n        @if(format12 && !format24){\n        <div class=\"timepicker-mode-wrapper d-flex flex-column justify-content-center\">\n          <button\n            type=\"button\"\n            class=\"timepicker-hour-mode timepicker-am\"\n            (click)=\"_setAmPm('AM')\"\n            (keydown.enter)=\"_setAmPm('AM')\"\n            tabindex=\"0\"\n            [ngClass]=\"{ active: _selectedTime.ampm === 'AM'}\"\n          >\n            {{options.amLabel}}\n          </button>\n          <button\n            class=\"timepicker-hour-mode timepicker-pm\"\n            tabindex=\"0\"\n            [ngClass]=\"{ active: _selectedTime.ampm === 'PM'}\"\n            (click)=\"_setAmPm('PM')\"\n            (keydown.enter)=\"_setAmPm('PM')\"\n          >\n            {{options.pmLabel}}\n          </button>\n        </div>\n        }\n      </div>\n    </div>\n    <div\n      class=\"timepicker-clock-wrapper d-flex justify-content-center flex-column align-items-center\"\n    >\n      <div class=\"timepicker-clock\" #plate>\n        <span class=\"timepicker-middle-dot position-absolute\"></span>\n        <div class=\"timepicker-hand-pointer position-absolute\" #hand>\n          <div class=\"timepicker-circle position-absolute\"></div>\n        </div>\n        @if(_showHours){ @if(format24){\n        <div class=\"timepicker-clock-inner\">\n          @for(tick of _innerHoursTicks; track $index){\n          <span\n            class=\"timepicker-time-tips-inner\"\n            [ngClass]=\"{ disabled: tick.disabled, 'active': tick.time === _selectedTime.h || 0 + tick.time === _selectedTime.h}\"\n            [ngStyle]=\"{ left: tick.left + 'px', bottom: tick.bottom + 'px' }\"\n          >\n            <span class=\"timepicker-tips-inner-element\">{{ tick.time }}</span>\n          </span>\n          }\n        </div>\n        } @for (tick of _hoursTicks; track $index) {\n        <span\n          class=\"timepicker-time-tips-hours\"\n          [ngClass]=\"{ disabled: tick.disabled, 'active': tick.time === _selectedTime.h || 0 + tick.time === _selectedTime.h}\"\n          [ngStyle]=\"{ left: tick.left + 'px', bottom: tick.bottom + 'px' }\"\n          ><span class=\"timepicker-tips-element\">{{ tick.time }}</span></span\n        >\n        } } @else{ @for (tick of _minutesTicks; track $index) {\n        <span\n          class=\"timepicker-time-tips-minutes\"\n          [ngClass]=\"{ disabled: tick.disabled, 'active': tick.time === _selectedTime.m }\"\n          [ngStyle]=\"{ left: tick.left + 'px', bottom: tick.bottom + 'px' }\"\n        >\n          <span class=\"timepicker-tips-element\">{{ tick.time }}</span>\n        </span>\n        } }\n      </div>\n    </div>\n  </div>\n  <div class=\"timepicker-footer\">\n    <div class=\"d-flex justify-content-between w-100\">\n      @if(showClearBtn) {\n      <button\n        type=\"button\"\n        class=\"timepicker-button timepicker-clear\"\n        (click)=\"_clearBtnClicked()\"\n        tabindex=\"0\"\n      >\n        {{ options.clearLabel }}\n      </button>\n      }\n      <button\n        type=\"button\"\n        class=\"timepicker-button timepicker-cancel\"\n        (click)=\"_closeBtnClicked()\"\n        tabindex=\"0\"\n      >\n        {{ options.cancelLabel }}\n      </button>\n      <button\n        type=\"button\"\n        class=\"timepicker-button timepicker-submit\"\n        (click)=\"_okBtnClicked()\"\n        [ngClass]=\"{ disabled: _okButtonDisabled }\"\n        tabindex=\"0\"\n      >\n        {{ options.okLabel }}\n      </button>\n    </div>\n  </div>\n</div>\n} @else {\n<div\n  class=\"timepicker-container d-flex flex-column align-items-center justify-content-center\"\n  #container\n  [@fadeInOutTimepicker]=\"_contentAnimationState\"\n  (@fadeInOutTimepicker.done)=\"_onAnimationDone($event)\"\n  cdkTrapFocus\n  tabindex=\"-1\"\n>\n  <div\n    class=\"timepicker-elements timepicker-elements-inline d-flex flex-column justify-content-around\"\n  >\n    <div\n      class=\"timepicker-head timepicker-head-inline d-flex flex-row align-items-center justify-content-center\"\n    >\n      <div class=\"timepicker-head-content d-flex w-100 justify-content-evenly align-items-center\">\n        <div class=\"timepicker-current-wrapper\">\n          <span\n            #focus\n            class=\"timepicker-inline-hour-icons position-relative h-100\"\n            (click)=\"_showHoursClock()\"\n            (keydown.enter)=\"_showHoursClock()\"\n          >\n            <i\n              #hourUp\n              class=\"timepicker-icon-up timepicker-icon-inline-hour fas fa-chevron-up position-absolute text-white\"\n              [ngClass]=\"{ 'active': _isInlineHourButtonHovered() }\"\n            ></i>\n            <button\n              type=\"button\"\n              class=\"timepicker-current timepicker-current-inline timepicker-hour\"\n              tabindex=\"0\"\n              [ngClass]=\"{ active: _showHours }\"\n              (mouseover)=\"_isInlineHourButtonHovered.set(true)\"\n              (mouseleave)=\"_isInlineHourButtonHovered.set(false)\"\n            >\n              {{ _selectedTime.h }}\n            </button>\n            <i\n              #hourDown\n              class=\"timepicker-icon-down timepicker-icon-inline-hour fas fa-chevron-down position-absolute text-white\"\n              [ngClass]=\"{ 'active': _isInlineHourButtonHovered() }\"\n            ></i>\n          </span>\n          <button type=\"button\" class=\"timepicker-dot timepicker-current-inline\" disabled>:</button>\n          <span\n            #digitalMinute\n            class=\"timepicker-inline-minutes-icons position-relative h-100\"\n            [ngClass]=\"{'disabled': _minuteDigitalDisabled}\"\n            (click)=\"_showMinutesClock()\"\n            (keydown.enter)=\"_showMinutesClock()\"\n          >\n            <i\n              #minuteUp\n              class=\"timepicker-icon-up timepicker-icon-inline-minute fas fa-chevron-up position-absolute text-white\"\n              [ngClass]=\"{ 'active': _isInlineMinutButtoneHovered() }\"\n            ></i>\n            <button\n              type=\"button\"\n              class=\"timepicker-current timepicker-current-inline timepicker-minute\"\n              tabindex=\"0\"\n              [ngClass]=\"{ active: !_showHours }\"\n              (mouseover)=\"_isInlineMinutButtoneHovered.set(true)\"\n              (mouseleave)=\"_isInlineMinutButtoneHovered.set(false)\"\n            >\n              {{ _selectedTime.m }}\n            </button>\n            <i\n              #minuteDown\n              class=\"timepicker-icon-down timepicker-icon-inline-minute fas fa-chevron-down position-absolute text-white\"\n              [ngClass]=\"{ 'active': _isInlineMinutButtoneHovered() }\"\n            ></i>\n          </span>\n        </div>\n        <div class=\"timepicker-mode-wrapper d-flex justify-content-center\">\n          @if(format12 && !format24){\n          <button\n            type=\"button\"\n            class=\"timepicker-hour-mode timepicker-am me-2 ms-4\"\n            tabindex=\"0\"\n            (click)=\"_setAmPm('AM')\"\n            (keydown.enter)=\"_setAmPm('AM')\"\n            [ngClass]=\"{ active: _selectedTime.ampm === 'AM'}\"\n          >\n            {{options.amLabel}}\n          </button>\n          <button\n            class=\"timepicker-hour-mode timepicker-pm\"\n            (click)=\"_setAmPm('PM')\"\n            (keydown.enter)=\"_setAmPm('PM')\"\n            [ngClass]=\"{ active: _selectedTime.ampm === 'PM' }\"\n            tabindex=\"0\"\n          >\n            {{options.pmLabel}}\n          </button>\n          }\n          <button\n            type=\"button\"\n            class=\"timepicker-button timepicker-submit timepicker-submit-inline py-1 px-2 mb-0\"\n            tabindex=\"0\"\n            (click)=\"_okBtnClicked()\"\n            [ngClass]=\"{ disabled: _okButtonDisabled }\"\n          >\n            {{ options.okLabel }}\n          </button>\n        </div>\n        @if(!format12 && format24){\n        <button\n          class=\"timepicker-button timepicker-submit timepicker-submit-inline py-1 px-2 mb-0\"\n          tabindex=\"0\"\n        >\n          {{ options.okLabel }}\n        </button>\n        }\n      </div>\n    </div>\n  </div>\n</div>\n}\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.NgZone }, { type: i1.FocusMonitor }, { type: i0.ElementRef }, { type: i0.Renderer2 }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }], propDecorators: { plate: [{
                type: ViewChild,
                args: ['plate', { static: false }]
            }], hand: [{
                type: ViewChild,
                args: ['hand', { static: false }]
            }], focus: [{
                type: ViewChild,
                args: ['focus', { static: false }]
            }], digitalMinute: [{
                type: ViewChild,
                args: ['digitalMinute', { static: false }]
            }], container: [{
                type: ViewChild,
                args: ['container', { static: false }]
            }], hourUp: [{
                type: ViewChild,
                args: ['hourUp', { static: false }]
            }], hourDown: [{
                type: ViewChild,
                args: ['hourDown', { static: false }]
            }], minuteUp: [{
                type: ViewChild,
                args: ['minuteUp', { static: false }]
            }], minuteDown: [{
                type: ViewChild,
                args: ['minuteDown', { static: false }]
            }], handleKeyboardEvent: [{
                type: HostListener,
                args: ['keydown', ['$event']]
            }] } });

class MdbTimepickerComponent {
    _document;
    _cdRef;
    _overlay;
    _vcr;
    _renderer;
    autoClose = false;
    disabled = false;
    format12 = true;
    format24 = false;
    increment = false;
    inline = false;
    showClearBtn = true;
    maxTime = '';
    minTime = '';
    get options() {
        return this._options;
    }
    set options(value) {
        this._options = {
            ...this._options,
            ...value,
        };
    }
    _options = {
        amLabel: 'AM',
        cancelLabel: 'Cancel',
        clearLabel: 'Clear',
        okLabel: 'Ok',
        pmLabel: 'PM',
    };
    switchHoursToMinutesOnClick = true;
    timeChange = new EventEmitter();
    closed = new EventEmitter();
    opened = new EventEmitter();
    clear = new EventEmitter();
    _value = '12:00AM';
    _contentRef;
    _overlayRef;
    _portal;
    input;
    toggle;
    _selectionChange$ = new Subject();
    constructor(_document, _cdRef, _overlay, _vcr, _renderer) {
        this._document = _document;
        this._cdRef = _cdRef;
        this._overlay = _overlay;
        this._vcr = _vcr;
        this._renderer = _renderer;
    }
    _patchInputValues() {
        this._contentRef.instance.picker = this;
        this._contentRef.instance.autoClose = this.autoClose;
        this._contentRef.instance.options = this.options;
        this._contentRef.instance.increment = this.increment;
        this._contentRef.instance.format12 = this.format12;
        this._contentRef.instance.format24 = this.format24;
        this._contentRef.instance.value = this._timeToObj(this._value);
        this._contentRef.instance.inline = this.inline;
        this._contentRef.instance.showClearBtn = this.showClearBtn;
        this._contentRef.instance.switchHoursToMinutesOnClick = this.switchHoursToMinutesOnClick;
        if (this.maxTime) {
            this._contentRef.instance.maxTime = this._timeToObj(this.maxTime);
        }
        if (this.minTime) {
            this._contentRef.instance.minTime = this._timeToObj(this.minTime);
        }
        this._contentRef.instance.markForCheck();
    }
    _timeToObj(time) {
        const round = (x, roundBy) => {
            return x % roundBy < Math.round(roundBy / 2)
                ? x % roundBy === 0
                    ? x
                    : Math.ceil(x / roundBy) * roundBy
                : Math.floor(x / roundBy) * roundBy;
        };
        function toString(val) {
            return val < 10 ? `0${val}` : `${val}`;
        }
        const hour = Number(time.split(':')[0]);
        let minute = Number(time.split(':')[1].match(/\d+/g));
        const ampm = time.match(/AM|PM/i) || ['AM'];
        if (this.increment) {
            minute = round(minute, 5);
        }
        return {
            h: toString(hour),
            m: toString(minute),
            ampm: ampm[0].toUpperCase(),
        };
    }
    markForCheck() {
        this._cdRef.markForCheck();
    }
    open() {
        if (this.disabled) {
            return;
        }
        let overlayRef = this._overlayRef;
        if (!overlayRef) {
            this._portal = new ComponentPortal(MdbTimepickerContentComponent, this._vcr);
            overlayRef = this._overlay.create(this._getOverlayConfig());
            this._overlayRef = overlayRef;
        }
        if (overlayRef && this._overlayRef && !overlayRef.hasAttached()) {
            this._contentRef = this._overlayRef.attach(this._portal);
            this._patchInputValues();
            this._listenToOutsideClick();
        }
        if (!this.inline && this._hasVerticalScroll()) {
            const widthWithVerticalScroll = this._document.body.offsetWidth;
            this._renderer.setStyle(this._document.body, 'overflow', 'hidden');
            const widthWithoutVerticalScroll = this._document.body.offsetWidth;
            this._renderer.setStyle(this._document.body, 'padding-right', `${widthWithoutVerticalScroll - widthWithVerticalScroll}px`);
        }
        this._emitTimeOpenedEvent();
    }
    close() {
        this._contentRef.instance._startHideAnimation();
        if (this._overlayRef.backdropElement) {
            this._renderer.setStyle(this._overlayRef.backdropElement, 'opacity', '0');
        }
        this._contentRef.instance._hideAnimationDone.pipe(take$1(1)).subscribe(() => {
            if (this._overlayRef && this._overlayRef.hasAttached()) {
                this._destroyOverlay();
            }
            if (!this.inline) {
                this._renderer.removeStyle(this._document.body, 'overflow');
                this._renderer.removeStyle(this._document.body, 'padding-right');
            }
            this._emitTimeClosedEvent();
            if (this.toggle) {
                this.toggle.button.nativeElement.focus();
            }
            else {
                this.input.focus();
            }
        });
    }
    _emitTimeChangeEvent(value) {
        this.timeChange.emit(value);
    }
    _emitTimeClosedEvent() {
        this.closed.emit();
    }
    _emitTimeOpenedEvent() {
        this.opened.emit();
    }
    _setValue(value) {
        if (value) {
            this._value = value;
        }
        else {
            this._value = '12:00 AM';
        }
        if (value === '') {
            this._renderer.removeClass(this.input, 'active');
        }
        else {
            this._renderer.addClass(this.input, 'active');
        }
    }
    setInput(input) {
        this.input = input.el.nativeElement;
        input._valueChange.subscribe((val) => {
            let match;
            if (this.format24) {
                match = val && val.match(/\d\d:\d\d/gi);
            }
            else {
                match = val && val.match(/\d\d:\d\d\s?(AM|PM)/gi);
            }
            if (match) {
                this._value = match[0];
            }
            else {
                this._value = '12:00 AM';
            }
        });
    }
    onChangeCb = () => { };
    onTouchedCb = () => { };
    registerOnChange(fn) {
        this.onChangeCb = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedCb = fn;
    }
    _hasVerticalScroll() {
        return this._document.body.scrollHeight > this._document.documentElement.clientHeight;
    }
    _getOverlayConfig() {
        const inlinePositionStrategy = this._overlay
            .position()
            .flexibleConnectedTo(this.input)
            .withPositions(this._getPositions())
            .withFlexibleDimensions(false);
        const dialogPositionStrategy = this._overlay
            .position()
            .global()
            .centerHorizontally()
            .centerVertically();
        const inlineScrollStrategy = this._overlay.scrollStrategies.reposition();
        const dialogScrollStrategy = this._overlay.scrollStrategies.noop();
        const positionStrategy = this.inline ? inlinePositionStrategy : dialogPositionStrategy;
        const scrollStrategy = this.inline ? inlineScrollStrategy : dialogScrollStrategy;
        const overlayConfig = new OverlayConfig({
            hasBackdrop: this.inline ? false : true,
            backdropClass: 'mdb-timepicker-backdrop',
            scrollStrategy,
            positionStrategy,
        });
        return overlayConfig;
    }
    _getPositions() {
        return [
            {
                originX: 'start',
                originY: 'bottom',
                overlayX: 'start',
                overlayY: 'top',
            },
            {
                originX: 'start',
                originY: 'top',
                overlayX: 'start',
                overlayY: 'bottom',
            },
        ];
    }
    _destroyOverlay() {
        if (this._overlayRef) {
            this._overlayRef.dispose();
            this._overlayRef = null;
        }
    }
    _listenToOutsideClick() {
        if (this._overlayRef) {
            merge(this._overlayRef.outsidePointerEvents(), this._overlayRef.keydownEvents().pipe(filter((event) => {
                // Closing on alt + up is only valid when there's an input associated with the datepicker.
                return event.key === 'Escape';
            }))).subscribe((event) => {
                if (event) {
                    event.preventDefault();
                }
                this.close();
            });
        }
    }
    ngOnDestroy() {
        this._destroyOverlay();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerComponent, deps: [{ token: DOCUMENT }, { token: i0.ChangeDetectorRef }, { token: i1$1.Overlay }, { token: i0.ViewContainerRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "16.1.0", version: "19.2.1", type: MdbTimepickerComponent, isStandalone: false, selector: "mdb-timepicker", inputs: { autoClose: ["autoClose", "autoClose", booleanAttribute], disabled: ["disabled", "disabled", booleanAttribute], format12: ["format12", "format12", booleanAttribute], format24: ["format24", "format24", booleanAttribute], increment: ["increment", "increment", booleanAttribute], inline: ["inline", "inline", booleanAttribute], showClearBtn: ["showClearBtn", "showClearBtn", booleanAttribute], maxTime: "maxTime", minTime: "minTime", options: "options", switchHoursToMinutesOnClick: ["switchHoursToMinutesOnClick", "switchHoursToMinutesOnClick", booleanAttribute] }, outputs: { timeChange: "timeChange", closed: "closed", opened: "opened", clear: "clear" }, exportAs: ["mdbTimePicker"], ngImport: i0, template: '', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerComponent, decorators: [{
            type: Component,
            args: [{
                    template: '',
                    selector: 'mdb-timepicker',
                    exportAs: 'mdbTimePicker',
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i0.ChangeDetectorRef }, { type: i1$1.Overlay }, { type: i0.ViewContainerRef }, { type: i0.Renderer2 }], propDecorators: { autoClose: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], format12: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], format24: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], increment: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], inline: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], showClearBtn: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], maxTime: [{
                type: Input
            }], minTime: [{
                type: Input
            }], options: [{
                type: Input
            }], switchHoursToMinutesOnClick: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], timeChange: [{
                type: Output
            }], closed: [{
                type: Output
            }], opened: [{
                type: Output
            }], clear: [{
                type: Output
            }] } });

const MDB_TIMEPICKER_TOGGLE_ICON = new InjectionToken('MdbTimepickerToggleIconDirective');
class MdbTimepickerToggleIconDirective {
    template;
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerToggleIconDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.1", type: MdbTimepickerToggleIconDirective, isStandalone: false, selector: "[mdbTimepickerToggleIcon]", providers: [
            { provide: MDB_TIMEPICKER_TOGGLE_ICON, useExisting: MdbTimepickerToggleIconDirective },
        ], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerToggleIconDirective, decorators: [{
            type: Directive,
            args: [{
                    // tslint:disable-next-line: directive-selector
                    selector: '[mdbTimepickerToggleIcon]',
                    providers: [
                        { provide: MDB_TIMEPICKER_TOGGLE_ICON, useExisting: MdbTimepickerToggleIconDirective },
                    ],
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }] });

class MdbTimepickerToggleComponent {
    _cdRef;
    _vcr;
    button;
    _iconRef;
    mdbTimepickerToggle;
    icon = 'far fa-clock';
    disabled = false;
    handleClick() {
        if (this.disabled) {
            return;
        }
        this.mdbTimepickerToggle.open();
    }
    get iconRef() {
        return this._iconPortal;
    }
    _iconPortal = null;
    constructor(_cdRef, _vcr) {
        this._cdRef = _cdRef;
        this._vcr = _vcr;
    }
    ngOnInit() {
        this.mdbTimepickerToggle.toggle = this;
    }
    ngAfterContentInit() {
        if (this._iconRef) {
            this._createIconPortal();
        }
    }
    _createIconPortal() {
        this._iconPortal = new TemplatePortal(this._iconRef, this._vcr);
    }
    markForCheck() {
        this._cdRef.markForCheck();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerToggleComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "16.1.0", version: "19.2.1", type: MdbTimepickerToggleComponent, isStandalone: false, selector: "mdb-timepicker-toggle", inputs: { mdbTimepickerToggle: "mdbTimepickerToggle", icon: "icon", disabled: ["disabled", "disabled", booleanAttribute] }, host: { listeners: { "click": "handleClick()" } }, queries: [{ propertyName: "_iconRef", first: true, predicate: MDB_TIMEPICKER_TOGGLE_ICON, descendants: true, read: TemplateRef, static: true }], viewQueries: [{ propertyName: "button", first: true, predicate: ["button"], descendants: true, static: true }], ngImport: i0, template: "<button\n  type=\"button\"\n  [attr.disabled]=\"disabled ? '' : null\"\n  #button\n  class=\"timepicker-toggle-button\"\n>\n  <ng-container *ngIf=\"!iconRef\"><i class=\"{{ icon }} fa-sm timepicker-icon\"></i></ng-container>\n  <ng-template [ngIf]=\"iconRef\">\n    <ng-template [cdkPortalOutlet]=\"iconRef\"></ng-template>\n  </ng-template>\n</button>\n", dependencies: [{ kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2$1.CdkPortalOutlet, selector: "[cdkPortalOutlet]", inputs: ["cdkPortalOutlet"], outputs: ["attached"], exportAs: ["cdkPortalOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerToggleComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-timepicker-toggle', encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, standalone: false, template: "<button\n  type=\"button\"\n  [attr.disabled]=\"disabled ? '' : null\"\n  #button\n  class=\"timepicker-toggle-button\"\n>\n  <ng-container *ngIf=\"!iconRef\"><i class=\"{{ icon }} fa-sm timepicker-icon\"></i></ng-container>\n  <ng-template [ngIf]=\"iconRef\">\n    <ng-template [cdkPortalOutlet]=\"iconRef\"></ng-template>\n  </ng-template>\n</button>\n" }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.ViewContainerRef }], propDecorators: { button: [{
                type: ViewChild,
                args: ['button', { static: true }]
            }], _iconRef: [{
                type: ContentChild,
                args: [MDB_TIMEPICKER_TOGGLE_ICON, { read: TemplateRef, static: true }]
            }], mdbTimepickerToggle: [{
                type: Input
            }], icon: [{
                type: Input
            }], disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], handleClick: [{
                type: HostListener,
                args: ['click']
            }] } });

const MDB_TIMEPICKER_VALUE_ACCESSOR = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => MdbTimepickerDirective),
    multi: true,
};
class MdbTimepickerDirective {
    el;
    onChange = () => { };
    onTouched = () => { };
    disabled = false;
    mdbTimepicker;
    get value() {
        return this._value;
    }
    set value(value) {
        this._value = value;
        this._valueChange.emit(this._value);
        if (value) {
            this.el.nativeElement.value = value;
        }
        else {
            this.el.nativeElement.value = null;
        }
    }
    _value;
    _valueChange = new EventEmitter();
    constructor(el) {
        this.el = el;
    }
    handleInput(event) {
        this.onChange(event.target.value);
        this._valueChange.emit(event.target.value);
    }
    ngAfterViewInit() {
        this.mdbTimepicker.setInput(this);
        this._valueChange.emit(this._value);
        this.mdbTimepicker._selectionChange$.subscribe((selectedValue) => {
            this.value = selectedValue;
            this.onChange(selectedValue);
        });
    }
    // Control value accessor methods
    writeValue(value) {
        this.value = value;
        this.mdbTimepicker._selectionChange$.next(this._value);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
        this.mdbTimepicker.disabled = this.disabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "16.1.0", version: "19.2.1", type: MdbTimepickerDirective, isStandalone: false, selector: "[mdbTimepicker]", inputs: { disabled: ["disabled", "disabled", booleanAttribute], mdbTimepicker: "mdbTimepicker", value: "value" }, host: { listeners: { "blur": "onTouched()", "input": "handleInput($event)" } }, providers: [MDB_TIMEPICKER_VALUE_ACCESSOR], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerDirective, decorators: [{
            type: Directive,
            args: [{
                    // eslint-disable-next-line @angular-eslint/directive-selector
                    selector: '[mdbTimepicker]',
                    host: { '(blur)': 'onTouched()' },
                    providers: [MDB_TIMEPICKER_VALUE_ACCESSOR],
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { disabled: [{
                type: Input,
                args: [{ transform: booleanAttribute }]
            }], mdbTimepicker: [{
                type: Input
            }], value: [{
                type: Input
            }], handleInput: [{
                type: HostListener,
                args: ['input', ['$event']]
            }] } });

class MdbTimepickerModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerModule, bootstrap: [MdbTimepickerContentComponent], declarations: [MdbTimepickerComponent,
            MdbTimepickerToggleComponent,
            MdbTimepickerDirective,
            MdbTimepickerContentComponent,
            MdbTimepickerToggleIconDirective], imports: [CommonModule, OverlayModule, A11yModule, PortalModule], exports: [MdbTimepickerComponent,
            MdbTimepickerToggleComponent,
            MdbTimepickerDirective,
            MdbTimepickerToggleIconDirective] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerModule, imports: [CommonModule, OverlayModule, A11yModule, PortalModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbTimepickerModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, OverlayModule, A11yModule, PortalModule],
                    declarations: [
                        MdbTimepickerComponent,
                        MdbTimepickerToggleComponent,
                        MdbTimepickerDirective,
                        MdbTimepickerContentComponent,
                        MdbTimepickerToggleIconDirective,
                    ],
                    exports: [
                        MdbTimepickerComponent,
                        MdbTimepickerToggleComponent,
                        MdbTimepickerDirective,
                        MdbTimepickerToggleIconDirective,
                    ],
                    bootstrap: [MdbTimepickerContentComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MDB_TIMEPICKER_VALUE_ACCESSOR, MdbTimepickerComponent, MdbTimepickerContentComponent, MdbTimepickerDirective, MdbTimepickerModule, MdbTimepickerToggleComponent, MdbTimepickerToggleIconDirective };
//# sourceMappingURL=mdb-angular-ui-kit-timepicker.mjs.map
