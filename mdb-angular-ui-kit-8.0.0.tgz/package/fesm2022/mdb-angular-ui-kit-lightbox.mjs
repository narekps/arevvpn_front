import { coerceBooleanProperty } from '@angular/cdk/coercion';
import * as i0 from '@angular/core';
import { HostBinding, HostListener, Input, Directive, forwardRef, ViewChildren, ViewChild, Inject, ChangeDetectionStrategy, Component, EventEmitter, ContentChildren, Output, ViewEncapsulation, NgModule } from '@angular/core';
import { Subject, fromEvent, merge } from 'rxjs';
import * as i2 from '@angular/common';
import { DOCUMENT, CommonModule } from '@angular/common';
import * as i1$1 from '@angular/cdk/overlay';
import { OverlayConfig, OverlayModule } from '@angular/cdk/overlay';
import { ComponentPortal } from '@angular/cdk/portal';
import { trigger, transition, style, animate, keyframes } from '@angular/animations';
import { takeUntil, take, startWith, switchMap, filter } from 'rxjs/operators';
import * as i1 from '@angular/cdk/a11y';

class MdbLightboxItemDirective {
    el;
    caption;
    img;
    get disabled() {
        return this._disabled;
    }
    set disabled(value) {
        this._disabled = coerceBooleanProperty(value);
    }
    _disabled = false;
    click$ = new Subject();
    onClick() {
        if (this.disabled) {
            return;
        }
        this.click$.next(this);
    }
    get isDisabled() {
        return this.disabled;
    }
    constructor(el) {
        this.el = el;
    }
    ngOnDestroy() {
        this.click$.complete();
    }
    static ngAcceptInputType_flush;
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxItemDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "19.2.1", type: MdbLightboxItemDirective, isStandalone: false, selector: "[mdbLightboxItem]", inputs: { caption: "caption", img: "img", disabled: "disabled" }, host: { listeners: { "click": "onClick($event.target)" }, properties: { "class.lightbox-disabled": "this.isDisabled" } }, exportAs: ["mdbLightboxItem"], ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxItemDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[mdbLightboxItem]',
                    exportAs: 'mdbLightboxItem',
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { caption: [{
                type: Input
            }], img: [{
                type: Input
            }], disabled: [{
                type: Input
            }], onClick: [{
                type: HostListener,
                args: ['click', ['$event.target']]
            }], isDisabled: [{
                type: HostBinding,
                args: ['class.lightbox-disabled']
            }] } });

class MdbLightboxModalComponent {
    _renderer;
    _elementRef;
    _cdRef;
    _focusTrapFactory;
    _ngZone;
    _document;
    galleryToolbar;
    btnPrevious;
    btnNext;
    rightArrow;
    leftArrow;
    btnFullsreen;
    btnZoom;
    loader;
    imageWrappers;
    images;
    onHostMousemove() {
        this._resetToolsToggler();
    }
    onHostKeyup(event) {
        this._onKeyup(event);
    }
    onHostClick(target) {
        this._resetToolsToggler();
        if (target.tagName !== 'DIV') {
            return;
        }
        this.close();
    }
    lightbox;
    lightboxItems;
    activeLightboxItem;
    zoomLevel;
    index;
    animationState = '';
    slideRight;
    activeModalImageIndex = 1;
    _slideTimer;
    _toolsToggleTimer;
    _zoomTimer;
    _doubleTapTimer;
    _focusTrap;
    _previouslyFocusedElement;
    _fullscreen = false;
    _scale = 1;
    _mousedown = false;
    _positionX;
    _positionY;
    _mousedownPositionX;
    _mousedownPositionY;
    _originalPositionX;
    _originalPositionY;
    _tapCounter = 0;
    _tapTime = 0;
    _toolsTimeout = 4000;
    _doubleTapTimeout = 300;
    _pos = { x: 0, y: 0 };
    _touchDelta = 0;
    _destroy$ = new Subject();
    constructor(_renderer, _elementRef, _cdRef, _focusTrapFactory, _ngZone, _document, _lightbox) {
        this._renderer = _renderer;
        this._elementRef = _elementRef;
        this._cdRef = _cdRef;
        this._focusTrapFactory = _focusTrapFactory;
        this._ngZone = _ngZone;
        this._document = _document;
        this.lightbox = _lightbox;
    }
    ngAfterViewInit() {
        this.index = this.lightboxItems.indexOf(this.activeLightboxItem);
        this._setActiveImageData();
        this._setToolsToggleTimeout();
        this._disableScroll();
        this._previouslyFocusedElement = this._document.activeElement;
        this._focusTrap = this._focusTrapFactory.create(this._elementRef.nativeElement);
        this._focusTrap.focusInitialElementWhenReady();
        this._setDefaultAnimationStyle();
        this._preloadInactiveImages();
        this._ngZone.runOutsideAngular(() => {
            fromEvent(window, 'resize')
                .pipe(takeUntil(this._destroy$))
                .subscribe(() => {
                this._calculateImgSize();
            });
        });
    }
    ngOnDestroy() {
        // there was an error in the ecommerce gallery tests.
        // this._previouslyFocusedElement and this._focusTrap was null
        // therefore an if conditions was added
        if (this._previouslyFocusedElement) {
            this._previouslyFocusedElement.focus();
        }
        if (this._focusTrap) {
            this._focusTrap.destroy();
        }
        this._enableScroll();
        this._destroy$.next();
        this._destroy$.complete();
    }
    get activeImageElement() {
        return this.images.toArray()[this.activeModalImageIndex].nativeElement;
    }
    get activeImageWrapper() {
        return this.imageWrappers.toArray()[this.activeModalImageIndex].nativeElement;
    }
    get nextImageWrapper() {
        if (this.activeModalImageIndex < this.images.length - 1) {
            return this.imageWrappers.toArray()[this.activeModalImageIndex + 1].nativeElement;
        }
        else if ((this.activeModalImageIndex = this.images.length - 1)) {
            return this.imageWrappers.toArray()[0].nativeElement;
        }
    }
    get previousImageWrapper() {
        if (this.activeModalImageIndex > 0) {
            return this.imageWrappers.toArray()[this.activeModalImageIndex - 1].nativeElement;
        }
        else if ((this.activeModalImageIndex = 0)) {
            return this.imageWrappers.toArray()[this.images.length].nativeElement;
        }
    }
    get nextImage() {
        if (this.activeModalImageIndex < this.images.length - 1) {
            return this.images.toArray()[this.activeModalImageIndex + 1].nativeElement;
        }
        else if (this.activeModalImageIndex === this.images.length - 1) {
            return this.images.toArray()[0].nativeElement;
        }
    }
    get previousImage() {
        if (this.activeModalImageIndex > 0) {
            return this.images.toArray()[this.activeModalImageIndex - 1].nativeElement;
        }
        else if (this.activeModalImageIndex === 0) {
            return this.images.toArray()[this.images.length - 1].nativeElement;
        }
    }
    onMousedown(event) {
        const touch = event.touches;
        const x = touch ? touch[0].clientX : event.clientX;
        const y = touch ? touch[0].clientY : event.clientY;
        this._originalPositionX = parseFloat(this.activeImageElement.style.left) || 0;
        this._originalPositionY = parseFloat(this.activeImageElement.style.top) || 0;
        this._positionX = this._originalPositionX;
        this._positionY = this._originalPositionY;
        this._mousedownPositionX = x * (1 / this._scale) - this._positionX;
        this._mousedownPositionY = y * (1 / this._scale) - this._positionY;
        this._mousedown = true;
    }
    onMousemove(event) {
        if (!this._mousedown)
            return;
        const touch = event.touches;
        const x = touch ? touch[0].clientX : event.clientX;
        const y = touch ? touch[0].clientY : event.clientY;
        if (touch)
            this._resetToolsToggler();
        if (this._scale !== 1) {
            this._positionX = x * (1 / this._scale) - this._mousedownPositionX;
            this._positionY = y * (1 / this._scale) - this._mousedownPositionY;
            this._renderer.setStyle(this.activeImageElement, 'left', `${this._positionX}px`);
            this._renderer.setStyle(this.activeImageElement, 'top', `${this._positionY}px`);
        }
        else {
            if (this.lightboxItems.length <= 1)
                return;
            this._positionX = x * (1 / this._scale) - this._mousedownPositionX;
            this._renderer.setStyle(this.activeImageElement, 'left', `${this._positionX}px`);
        }
    }
    onMouseup(event) {
        this._mousedown = false;
        this._moveImg(event.target);
        this._checkDoubleTap(event);
    }
    toggleZoom() {
        if (this._scale <= 1) {
            this.zoomIn();
        }
        else {
            this.zoomOut();
        }
    }
    close() {
        this._renderer.setStyle(this.activeImageWrapper, 'transform', 'scale(0.25)');
        this._renderer.setStyle(this.activeImageWrapper, 'opacity', 0);
        this.lightbox.close();
    }
    toggleFullscreen() {
        if (this._fullscreen === false) {
            this._renderer.addClass(this.btnFullsreen.nativeElement, 'active');
            if (this._elementRef.nativeElement.requestFullscreen) {
                this._elementRef.nativeElement.requestFullscreen();
            }
            this._fullscreen = true;
        }
        else {
            this._renderer.removeClass(this.btnFullsreen.nativeElement, 'active');
            if (this._document.exitFullscreen) {
                this._document.exitFullscreen();
            }
            this._fullscreen = false;
        }
    }
    _setDefaultAnimationStyle() {
        this.imageWrappers.toArray().forEach((wrapper, index) => {
            if (index === this.activeModalImageIndex) {
                return;
            }
            const isNextWrapper = index > this.index;
            this._renderer.setStyle(wrapper.nativeElement, 'left', isNextWrapper ? '-100%' : '100%');
            this._renderer.setStyle(wrapper.nativeElement, 'transform', 'scale(0.25)');
        });
    }
    _preloadInactiveImages() {
        const nextIndex = this.index < this.lightboxItems.length - 1 ? this.index + 1 : 0;
        const previousIndex = this.index > 0 ? this.index - 1 : this.lightboxItems.length - 1;
        this.previousImage.src =
            this.lightboxItems[previousIndex].img ||
                this.lightboxItems[previousIndex].el.nativeElement.src;
        this.previousImage.alt = this.lightboxItems[previousIndex].el.nativeElement.alt;
        this.nextImage.src =
            this.lightboxItems[nextIndex].img || this.lightboxItems[nextIndex].el.nativeElement.src;
        this.nextImage.alt = this.lightboxItems[nextIndex].el.nativeElement.alt;
    }
    _onKeyup(event) {
        this._resetToolsToggler();
        switch (event.key) {
            case 'ArrowRight':
                this.slide();
                break;
            case 'ArrowLeft':
                this.slide('left');
                break;
            case 'Escape':
                this.close();
                break;
            case 'Home':
                this.slide('first');
                break;
            case 'End':
                this.slide('last');
                break;
            case 'ArrowUp':
                this.zoomIn();
                break;
            case 'ArrowDown':
                this.zoomOut();
                break;
            default:
                break;
        }
    }
    _moveImg(target) {
        if (this._scale !== 1 || target !== this.activeImageElement || this.lightboxItems.length <= 1) {
            return;
        }
        const movement = this._positionX - this._originalPositionX;
        if (movement > 0) {
            this.slide('left');
        }
        else if (movement < 0) {
            this.slide();
        }
    }
    _setActiveImageData() {
        this.activeImageElement.src =
            this.activeLightboxItem.img || this.activeLightboxItem.el.nativeElement.src;
        this.activeImageElement.alt = this.activeLightboxItem.el.nativeElement.alt;
    }
    _setNewPositionOnZoomIn(event) {
        this._positionX = window.innerWidth / 2 - event.offsetX - 50;
        this._positionY = window.innerHeight / 2 - event.offsetY - 50;
        this._renderer.setStyle(this.activeImageElement, 'transition', 'all 0.5s ease-out');
        this._renderer.setStyle(this.activeImageElement, 'left', `${this._positionX}px`);
        this._renderer.setStyle(this.activeImageElement, 'top', `${this._positionY}px`);
    }
    _resetToolsToggler() {
        this.toggleToolbar(1);
        clearTimeout(this._toolsToggleTimer);
        this._setToolsToggleTimeout();
    }
    toggleToolbar(opacity) {
        this._renderer.setStyle(this.galleryToolbar.nativeElement, 'opacity', opacity);
        if (this.lightboxItems.length <= 1 || !this.leftArrow || !this.rightArrow) {
            return;
        }
        this._renderer.setStyle(this.leftArrow.nativeElement, 'opacity', opacity);
        this._renderer.setStyle(this.rightArrow.nativeElement, 'opacity', opacity);
    }
    _setToolsToggleTimeout() {
        this._toolsToggleTimer = setTimeout(() => {
            this.toggleToolbar(0);
            clearTimeout(this._toolsToggleTimer);
        }, this._toolsTimeout);
    }
    onWheel(event) {
        const delta = Math.max(-1, Math.min(1, event.deltaY));
        this.zoomOnWheel(event.x, event.y, delta);
    }
    onTouchMove(touches) {
        if (touches.length !== 2) {
            return;
        }
        const fingersDistanceHypot = Math.hypot(touches[0].pageX - touches[1].pageX, touches[0].pageY - touches[1].pageY);
        if (this._touchDelta > fingersDistanceHypot) {
            this.zoomOut();
        }
        if (this._touchDelta < fingersDistanceHypot) {
            this.zoomIn();
        }
    }
    onTouchStart(touches) {
        if (touches.length !== 2) {
            return;
        }
        //get rough estimate of distance between two fingers
        this._touchDelta = Math.hypot(touches[0].pageX - touches[1].pageX, touches[0].pageY - touches[1].pageY);
    }
    zoomOnWheel(x, y, delta) {
        if (-delta > 0) {
            this.lightbox.lightboxZoomIn.emit();
        }
        else {
            this.lightbox.lightboxZoomOut.emit();
        }
        this._renderer.setStyle(this.activeImageElement, 'transition', 'none');
        const activeImageClientRect = this.activeImageElement.getBoundingClientRect();
        const pointerX = (x - activeImageClientRect.left) / this._scale;
        const pointerY = (y - activeImageClientRect.top) / this._scale;
        const targetX = (pointerX - this._pos.x) / this._scale;
        const targetY = (pointerY - this._pos.y) / this._scale;
        this._scale += -delta * this.zoomLevel;
        const max_scale = 3;
        const min_scale = 1;
        this._scale = Math.max(min_scale, Math.min(max_scale, this._scale));
        if (this._scale === 1) {
            this._pos.x = 0;
            this._pos.y = 0;
        }
        else {
            this._pos.x = -targetX * this._scale + pointerX;
            this._pos.y = -targetY * this._scale + pointerY;
        }
        this._renderer.setStyle(this.activeImageElement, 'transition', '');
        this._renderer.setStyle(this.activeImageElement, 'transform', `translate(${this._pos.x}px,${this._pos.y}px) scale(${this._scale})`);
        this._updateZoomBtn();
        if (-delta > 0) {
            this.lightbox.lightboxZoomedIn.emit();
        }
        else {
            this.lightbox.lightboxZoomedOut.emit();
        }
    }
    zoomIn(position) {
        if (this._scale >= 3) {
            return;
        }
        this.lightbox.lightboxZoomIn.emit();
        this._pos.x = position ? -position.x : -this.activeImageElement.width / 2;
        this._pos.y = position ? -position.y : -this.activeImageElement.height / 2;
        this._scale += this.zoomLevel;
        this._renderer.setStyle(this.activeImageElement, 'transform', `translate(${this._pos.x}px,${this._pos.y}px) scale(${this._scale})`);
        this._updateZoomBtn();
        this.lightbox.lightboxZoomedIn.emit();
    }
    zoomOut() {
        if (this._scale <= 1) {
            return;
        }
        this.lightbox.lightboxZoomOut.emit();
        this._pos.x = 0;
        this._pos.y = 0;
        this._scale = 1;
        this._renderer.setStyle(this.activeImageElement, 'transform', `translate(${this._pos.x}px,${this._pos.y}px) scale(${this._scale})`);
        this._updateZoomBtn();
        this._updateImgPosition();
        this.lightbox.lightboxZoomedOut.emit();
    }
    slide(target = 'right') {
        if (this.lightboxItems.length <= 1) {
            return;
        }
        this.lightbox.lightboxSlide.emit();
        if (target === 'right' || target === 'first') {
            this.slideRight = true;
        }
        else {
            this.slideRight = false;
        }
        clearTimeout(this._slideTimer);
        this._renderer.setStyle(this.activeImageWrapper, 'transform', 'scale(0.25)');
        this._renderer.setStyle(this.activeImageWrapper, 'left', this.slideRight ? '-100%' : '100%');
        if (target === 'right' || target === 'first') {
            this.slideRight = true;
        }
        else {
            this.slideRight = false;
        }
        clearTimeout(this._slideTimer);
        this._renderer.setStyle(this.activeImageWrapper, 'transform', 'scale(0.25)');
        this._renderer.setStyle(this.activeImageWrapper, 'left', this.slideRight ? '-100%' : '100%');
        switch (target) {
            case 'right':
                this.index + 1 === this.lightboxItems.length ? (this.index = 0) : (this.index += 1);
                this.activeModalImageIndex + 1 === this.imageWrappers.length
                    ? (this.activeModalImageIndex = 0)
                    : (this.activeModalImageIndex += 1);
                break;
            case 'left':
                this.index - 1 < 0 ? (this.index = this.lightboxItems.length - 1) : (this.index -= 1);
                this.activeModalImageIndex - 1 < 0
                    ? (this.activeModalImageIndex = this.imageWrappers.length - 1)
                    : (this.activeModalImageIndex -= 1);
                break;
            case 'first':
                this.index = 0;
                this.activeModalImageIndex = 0;
                break;
            case 'last':
                this.index = this.lightboxItems.length - 1;
                this.activeModalImageIndex = 2;
                break;
            default:
                break;
        }
        this._updateActiveLightboxItem();
        this._preloadInactiveImages();
        if (this.activeImageElement.src) {
            return;
        }
        fromEvent(this.activeImageWrapper, 'transitionend')
            .pipe(take(1))
            .subscribe(() => {
            this._showLoader();
        });
    }
    reset() {
        if (this._fullscreen) {
            this.toggleFullscreen();
        }
        this._restoreDefaultPosition();
        this._restoreDefaultZoom();
        clearTimeout(this._toolsToggleTimer);
        clearTimeout(this._doubleTapTimer);
    }
    _disableScroll() {
        this._renderer.addClass(this._document.body, 'disabled-scroll');
        if (this._document.documentElement.scrollHeight > this._document.documentElement.clientHeight) {
            this._renderer.addClass(this._document.body, 'replace-scrollbar');
        }
    }
    _enableScroll() {
        this._renderer.removeClass(this._document.body, 'disabled-scroll');
        this._renderer.removeClass(this._document.body, 'replace-scrollbar');
    }
    _restoreDefaultZoom() {
        if (this._scale !== 1) {
            this.zoomOut();
        }
    }
    _updateImgPosition() {
        if (this._scale === 1) {
            this._restoreDefaultPosition();
        }
    }
    _checkDoubleTap(event) {
        clearTimeout(this._doubleTapTimer);
        const currentTime = new Date().getTime();
        const tapLength = currentTime - this._tapTime;
        if (this._tapCounter > 0 && tapLength < 500) {
            this._onDoubleClick(event);
            this._doubleTapTimer = setTimeout(() => {
                this._tapTime = new Date().getTime();
                this._tapCounter = 0;
            }, this._doubleTapTimeout);
        }
        else {
            this._tapCounter++;
            this._tapTime = new Date().getTime();
        }
    }
    _onDoubleClick(event) {
        const touchEvent = event;
        if (touchEvent.touches) {
            this._setNewPositionOnZoomIn(event);
        }
        if (this._scale !== 1) {
            this._restoreDefaultZoom();
        }
        else {
            const activeImageClientRect = this.activeImageElement.getBoundingClientRect();
            const e = event;
            const pointerX = (e.x - activeImageClientRect.left) / this._scale;
            const pointerY = (e.y - activeImageClientRect.top) / this._scale;
            this.zoomIn({ x: pointerX, y: pointerY });
        }
    }
    _updateZoomBtn() {
        if (this._scale > 1) {
            this._renderer.addClass(this.btnZoom.nativeElement, 'active');
            this._renderer.setAttribute(this.btnZoom.nativeElement, 'aria-label', 'Zoom out');
        }
        else {
            this._renderer.removeClass(this.btnZoom.nativeElement, 'active');
            this._renderer.setAttribute(this.btnZoom.nativeElement, 'aria-label', 'Zoom in');
        }
    }
    _restoreDefaultPosition() {
        clearTimeout(this._zoomTimer);
        this._renderer.setStyle(this.activeImageElement, 'left', 0);
        this._renderer.setStyle(this.activeImageElement, 'top', 0);
        this._renderer.setStyle(this.activeImageElement, 'transition', 'all 0.5s ease-out');
        this._calculateImgSize();
        setTimeout(() => {
            this._renderer.setStyle(this.activeImageElement, 'transition', '');
        }, 500);
    }
    _updateActiveLightboxItem() {
        this.activeLightboxItem = this.lightboxItems[this.index];
        this._setActiveImageData();
        this._cdRef.markForCheck();
    }
    load(index) {
        if (index !== this.activeModalImageIndex) {
            return;
        }
        this._hideLoader();
        if (this.activeImageWrapper.style.transform == 'scale(0.25)') {
            this._renderer.setStyle(this.activeImageWrapper, 'transition', 'none');
            this._renderer.setStyle(this.activeImageWrapper, 'left', this.slideRight ? '100%' : '-100%');
            this._slideTimer = setTimeout(() => {
                this._renderer.setStyle(this.activeImageWrapper, 'transition', '');
                this._renderer.setStyle(this.activeImageWrapper, 'left', '0');
                this._renderer.setStyle(this.activeImageWrapper, 'transform', 'scale(1)');
                this.lightbox.lightboxSlided.emit();
            }, 0);
        }
        this._calculateImgSize();
    }
    _showLoader() {
        if (this.activeImageElement.src) {
            return;
        }
        this._renderer.setStyle(this.loader.nativeElement, 'opacity', 1);
    }
    _hideLoader() {
        this._renderer.setStyle(this.loader.nativeElement, 'opacity', 0);
    }
    _calculateImgSize() {
        if (this.activeImageElement.width >= this.activeImageElement.height) {
            this._renderer.setStyle(this.activeImageElement, 'maxWidth', '100%');
            this._renderer.setStyle(this.activeImageElement, 'height', 'auto');
            const top = `${(this.activeImageWrapper.offsetHeight - this.activeImageElement.height) / 2}px`;
            const left = `${(this.activeImageWrapper.offsetWidth - this.activeImageElement.width) / 2}px`;
            this._renderer.setStyle(this.activeImageElement, 'left', left);
            this._renderer.setStyle(this.activeImageElement, 'top', top);
        }
        else {
            this._renderer.setStyle(this.activeImageElement, 'maxHeight', '100%');
            this._renderer.setStyle(this.activeImageElement, 'width', 'auto');
            const top = `${(this.activeImageWrapper.offsetHeight - this.activeImageElement.height) / 2}px`;
            const left = `${(this.activeImageWrapper.offsetWidth - this.activeImageElement.width) / 2}px`;
            this._renderer.setStyle(this.activeImageElement, 'left', left);
            this._renderer.setStyle(this.activeImageElement, 'top', top);
        }
        if (this.activeImageElement.width >= this.activeImageWrapper.offsetWidth) {
            this._renderer.setStyle(this.activeImageElement, 'height', 'auto');
            const top = `${(this.activeImageWrapper.offsetHeight - this.activeImageElement.height) / 2}px`;
            this._renderer.setStyle(this.activeImageElement, 'top', top);
            this._renderer.setStyle(this.activeImageElement, 'left', 0);
        }
        if (this.activeImageElement.height >= this.activeImageWrapper.offsetHeight) {
            this._renderer.setStyle(this.activeImageElement, 'width', 'auto');
            this._renderer.setStyle(this.activeImageElement, 'top', 0);
            const left = `${(this.activeImageWrapper.offsetWidth - this.activeImageElement.width) / 2}px`;
            this._renderer.setStyle(this.activeImageElement, 'left', left);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxModalComponent, deps: [{ token: i0.Renderer2 }, { token: i0.ElementRef }, { token: i0.ChangeDetectorRef }, { token: i1.ConfigurableFocusTrapFactory }, { token: i0.NgZone }, { token: DOCUMENT }, { token: forwardRef(() => MdbLightboxComponent) }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbLightboxModalComponent, isStandalone: false, selector: "mdb-lightbox-modal", host: { listeners: { "mousemove": "onHostMousemove()", "keyup": "onHostKeyup($event)", "click": "onHostClick($event.target)" } }, viewQueries: [{ propertyName: "galleryToolbar", first: true, predicate: ["galleryToolbar"], descendants: true }, { propertyName: "btnPrevious", first: true, predicate: ["btnPrevious"], descendants: true }, { propertyName: "btnNext", first: true, predicate: ["btnNext"], descendants: true }, { propertyName: "rightArrow", first: true, predicate: ["rightArrow"], descendants: true }, { propertyName: "leftArrow", first: true, predicate: ["leftArrow"], descendants: true }, { propertyName: "btnFullsreen", first: true, predicate: ["btnFullsreen"], descendants: true }, { propertyName: "btnZoom", first: true, predicate: ["btnZoom"], descendants: true }, { propertyName: "loader", first: true, predicate: ["loader"], descendants: true }, { propertyName: "imageWrappers", predicate: ["imageWrapper"], descendants: true }, { propertyName: "images", predicate: ["image"], descendants: true }], ngImport: i0, template: "<div #galleryToolbar class=\"lightbox-gallery-toolbar\">\n  <div #loader class=\"lightbox-gallery-loader\" style=\"opacity: 0\">\n    <div class=\"spinner-grow text-light\" role=\"status\">\n      <span class=\"sr-only\">Loading...</span>\n    </div>\n  </div>\n  <div *ngIf=\"this.lightboxItems.length > 1\" class=\"lightbox-gallery-left-tools\">\n    <p class=\"lightbox-gallery-counter\">{{ index + 1 }} / {{ lightboxItems.length }}</p>\n  </div>\n  <div class=\"lightbox-gallery-right-tools\">\n    <button\n      type=\"button\"\n      #btnFullsreen\n      class=\"lightbox-gallery-button lightbox-gallery-fullscreen-btn\"\n      [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n      aria-label=\"Toggle fullscreen\"\n      (click)=\"toggleFullscreen()\"\n    ></button>\n    <button\n      type=\"button\"\n      #btnZoom\n      class=\"lightbox-gallery-button lightbox-gallery-zoom-btn\"\n      [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n      aria-label=\"Zoom in\"\n      (click)=\"toggleZoom()\"\n    ></button>\n    <button\n      type=\"button\"\n      class=\"lightbox-gallery-button lightbox-gallery-close-btn\"\n      [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n      aria-label=\"Close\"\n      (click)=\"close()\"\n    ></button>\n  </div>\n</div>\n\n<div class=\"lightbox-gallery-content\">\n  <ng-container *ngFor=\"let item of [].constructor(3); let index = index\">\n    <div \n      #imageWrapper\n      class=\"lightbox-gallery-image\"\n      [ngStyle]=\"{'opacity': activeModalImageIndex === index ? '1' : '0'}\"\n    >\n      <img\n        #image\n        draggable=\"false\"\n        @fade\n        (load)=\"load(index)\"\n        (mousedown)=\"onMousedown($event)\"\n        (mouseup)=\"onMouseup($event)\"\n        (mousemove)=\"onMousemove($event)\"\n        (swipeleft)=\"slide('right')\"\n        (swiperight)=\"slide('left')\"\n        (wheel)=\"onWheel($event)\"\n        (touchmove)=\"onTouchMove($event.touches)\"\n        (touchstart)=\"onTouchStart($event.touches)\"\n\n      />\n    </div>\n  </ng-container>\n</div>\n\n<div *ngIf=\"lightboxItems.length > 1\" #leftArrow class=\"lightbox-gallery-arrow-left\" style=\"opacity: 1\">\n  <button\n    type=\"button\"\n    #btnPrevious\n    aria-label=\"Previous\"\n    (click)=\"slide('left')\"\n    class=\"lightbox-gallery-button\"\n    [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n  ></button>\n</div>\n<div *ngIf=\"lightboxItems.length > 1\" #rightArrow class=\"lightbox-gallery-arrow-right\" style=\"opacity: 1\">\n  <button\n    type=\"button\"\n    #btnNext\n    aria-label=\"Next\"\n    (click)=\"slide('right')\"\n    class=\"lightbox-gallery-button\"\n    [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n  ></button>\n</div>\n<div class=\"lightbox-gallery-caption-wrapper\">\n  <p class=\"lightbox-gallery-caption\">\n    {{ activeLightboxItem.caption || activeLightboxItem.el.nativeElement.alt }}\n  </p>\n</div>\n", dependencies: [{ kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i2.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i2.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i2.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }], animations: [
            trigger('fade', [
                transition(':enter', [
                    style({ opacity: 0 }),
                    animate('1500ms', keyframes([
                        style({ opacity: 0, transform: 'scale3d(0.3, 0.3, 0.3)', offset: 0, easing: 'ease' }),
                        style({
                            opacity: 1,
                            transform: 'scale3d(1, 1, 1)',
                            offset: 0.5,
                            easing: 'ease',
                        }),
                    ])),
                ]),
                transition(':leave', [
                    style({ opacity: 1 }),
                    animate('1500ms', keyframes([
                        style({ opacity: 1, offset: 0 }),
                        style({ opacity: 0, transform: 'scale3d(0.3, 0.3, 0.3)', offset: 0.5 }),
                        style({ opacity: 0, offset: 1 }),
                    ])),
                ]),
            ]),
        ], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'mdb-lightbox-modal', changeDetection: ChangeDetectionStrategy.OnPush, animations: [
                        trigger('fade', [
                            transition(':enter', [
                                style({ opacity: 0 }),
                                animate('1500ms', keyframes([
                                    style({ opacity: 0, transform: 'scale3d(0.3, 0.3, 0.3)', offset: 0, easing: 'ease' }),
                                    style({
                                        opacity: 1,
                                        transform: 'scale3d(1, 1, 1)',
                                        offset: 0.5,
                                        easing: 'ease',
                                    }),
                                ])),
                            ]),
                            transition(':leave', [
                                style({ opacity: 1 }),
                                animate('1500ms', keyframes([
                                    style({ opacity: 1, offset: 0 }),
                                    style({ opacity: 0, transform: 'scale3d(0.3, 0.3, 0.3)', offset: 0.5 }),
                                    style({ opacity: 0, offset: 1 }),
                                ])),
                            ]),
                        ]),
                    ], standalone: false, template: "<div #galleryToolbar class=\"lightbox-gallery-toolbar\">\n  <div #loader class=\"lightbox-gallery-loader\" style=\"opacity: 0\">\n    <div class=\"spinner-grow text-light\" role=\"status\">\n      <span class=\"sr-only\">Loading...</span>\n    </div>\n  </div>\n  <div *ngIf=\"this.lightboxItems.length > 1\" class=\"lightbox-gallery-left-tools\">\n    <p class=\"lightbox-gallery-counter\">{{ index + 1 }} / {{ lightboxItems.length }}</p>\n  </div>\n  <div class=\"lightbox-gallery-right-tools\">\n    <button\n      type=\"button\"\n      #btnFullsreen\n      class=\"lightbox-gallery-button lightbox-gallery-fullscreen-btn\"\n      [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n      aria-label=\"Toggle fullscreen\"\n      (click)=\"toggleFullscreen()\"\n    ></button>\n    <button\n      type=\"button\"\n      #btnZoom\n      class=\"lightbox-gallery-button lightbox-gallery-zoom-btn\"\n      [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n      aria-label=\"Zoom in\"\n      (click)=\"toggleZoom()\"\n    ></button>\n    <button\n      type=\"button\"\n      class=\"lightbox-gallery-button lightbox-gallery-close-btn\"\n      [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n      aria-label=\"Close\"\n      (click)=\"close()\"\n    ></button>\n  </div>\n</div>\n\n<div class=\"lightbox-gallery-content\">\n  <ng-container *ngFor=\"let item of [].constructor(3); let index = index\">\n    <div \n      #imageWrapper\n      class=\"lightbox-gallery-image\"\n      [ngStyle]=\"{'opacity': activeModalImageIndex === index ? '1' : '0'}\"\n    >\n      <img\n        #image\n        draggable=\"false\"\n        @fade\n        (load)=\"load(index)\"\n        (mousedown)=\"onMousedown($event)\"\n        (mouseup)=\"onMouseup($event)\"\n        (mousemove)=\"onMousemove($event)\"\n        (swipeleft)=\"slide('right')\"\n        (swiperight)=\"slide('left')\"\n        (wheel)=\"onWheel($event)\"\n        (touchmove)=\"onTouchMove($event.touches)\"\n        (touchstart)=\"onTouchStart($event.touches)\"\n\n      />\n    </div>\n  </ng-container>\n</div>\n\n<div *ngIf=\"lightboxItems.length > 1\" #leftArrow class=\"lightbox-gallery-arrow-left\" style=\"opacity: 1\">\n  <button\n    type=\"button\"\n    #btnPrevious\n    aria-label=\"Previous\"\n    (click)=\"slide('left')\"\n    class=\"lightbox-gallery-button\"\n    [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n  ></button>\n</div>\n<div *ngIf=\"lightboxItems.length > 1\" #rightArrow class=\"lightbox-gallery-arrow-right\" style=\"opacity: 1\">\n  <button\n    type=\"button\"\n    #btnNext\n    aria-label=\"Next\"\n    (click)=\"slide('right')\"\n    class=\"lightbox-gallery-button\"\n    [ngClass]=\"{ 'fontawesome-pro': lightbox.fontAwesome === 'pro' }\"\n  ></button>\n</div>\n<div class=\"lightbox-gallery-caption-wrapper\">\n  <p class=\"lightbox-gallery-caption\">\n    {{ activeLightboxItem.caption || activeLightboxItem.el.nativeElement.alt }}\n  </p>\n</div>\n" }]
        }], ctorParameters: () => [{ type: i0.Renderer2 }, { type: i0.ElementRef }, { type: i0.ChangeDetectorRef }, { type: i1.ConfigurableFocusTrapFactory }, { type: i0.NgZone }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: MdbLightboxComponent, decorators: [{
                    type: Inject,
                    args: [forwardRef(() => MdbLightboxComponent)]
                }] }], propDecorators: { galleryToolbar: [{
                type: ViewChild,
                args: ['galleryToolbar']
            }], btnPrevious: [{
                type: ViewChild,
                args: ['btnPrevious']
            }], btnNext: [{
                type: ViewChild,
                args: ['btnNext']
            }], rightArrow: [{
                type: ViewChild,
                args: ['rightArrow']
            }], leftArrow: [{
                type: ViewChild,
                args: ['leftArrow']
            }], btnFullsreen: [{
                type: ViewChild,
                args: ['btnFullsreen']
            }], btnZoom: [{
                type: ViewChild,
                args: ['btnZoom']
            }], loader: [{
                type: ViewChild,
                args: ['loader']
            }], imageWrappers: [{
                type: ViewChildren,
                args: ['imageWrapper']
            }], images: [{
                type: ViewChildren,
                args: ['image']
            }], onHostMousemove: [{
                type: HostListener,
                args: ['mousemove']
            }], onHostKeyup: [{
                type: HostListener,
                args: ['keyup', ['$event']]
            }], onHostClick: [{
                type: HostListener,
                args: ['click', ['$event.target']]
            }] } });

class MdbLightboxComponent {
    _document;
    _overlay;
    _vcr;
    _renderer;
    zoomLevel = 1;
    fontAwesome = 'free';
    lightboxOpen = new EventEmitter();
    lightboxOpened = new EventEmitter();
    lightboxSlide = new EventEmitter();
    lightboxSlided = new EventEmitter();
    lightboxZoomIn = new EventEmitter();
    lightboxZoomedIn = new EventEmitter();
    lightboxZoomOut = new EventEmitter();
    lightboxZoomedOut = new EventEmitter();
    lightboxClose = new EventEmitter();
    lightboxClosed = new EventEmitter();
    lightboxItems;
    _destroy$ = new Subject();
    _contentRef;
    _overlayRef;
    _portal;
    // this getter is used by ecommerce gallery
    get activeSlideIndex() {
        return this._contentRef.instance.index;
    }
    constructor(_document, _overlay, _vcr, _renderer) {
        this._document = _document;
        this._overlay = _overlay;
        this._vcr = _vcr;
        this._renderer = _renderer;
    }
    ngAfterContentInit() {
        this.lightboxItems.changes
            .pipe(startWith(this.lightboxItems), switchMap((items) => {
            return merge(...items.map((item) => item.click$));
        }), takeUntil(this._destroy$))
            .subscribe((clickedItem) => {
            this.open(clickedItem);
        });
    }
    _patchInputValues(lightboxItem) {
        this._contentRef.instance.lightboxItems = this.lightboxItems.filter((item) => {
            return !item.disabled;
        });
        this._contentRef.instance.activeLightboxItem = lightboxItem;
        this._contentRef.instance.zoomLevel = this.zoomLevel;
    }
    _hasVerticalScroll() {
        return this._document.body.scrollHeight > this._document.documentElement.clientHeight;
    }
    open(lightboxItem) {
        let overlayRef = this._overlayRef;
        if (!overlayRef) {
            this.lightboxOpen.emit();
            this._portal = new ComponentPortal(MdbLightboxModalComponent, this._vcr);
            overlayRef = this._overlay.create(this._getOverlayConfig());
            this._overlayRef = overlayRef;
        }
        if (overlayRef && this._overlayRef && !overlayRef.hasAttached()) {
            this._contentRef = this._overlayRef.attach(this._portal);
            this._patchInputValues(lightboxItem);
            this._listenToOutsideClick();
            this._listenToPopstateEvent();
            if (this._hasVerticalScroll) {
                const widthWithVerticalScroll = this._document.body.offsetWidth;
                this._renderer.setStyle(this._document.body, 'overflow', 'hidden');
                const widthWithoutVerticalScroll = this._document.body.offsetWidth;
                this._renderer.setStyle(this._document.body, 'padding-right', `${widthWithoutVerticalScroll - widthWithVerticalScroll}px`);
            }
            this.lightboxOpened.emit();
        }
    }
    close() {
        if (this._overlayRef && this._overlayRef.backdropElement) {
            this.lightboxClose.emit();
            const cssTransitionDuration = parseFloat(getComputedStyle(this._overlayRef.backdropElement).transitionDuration) * 1000;
            setTimeout(() => {
                this._destroyOverlay();
                this._renderer.removeStyle(this._document.body, 'overflow');
                this._renderer.removeStyle(this._document.body, 'padding-right');
                this.lightboxClosed.emit();
            }, cssTransitionDuration);
        }
    }
    slide(direction) {
        this._contentRef.instance.slide(direction);
    }
    zoomIn() {
        this._contentRef.instance.zoomIn();
    }
    zoomOut() {
        this._contentRef.instance.zoomOut();
    }
    toggleFullscreen() {
        this._contentRef.instance.toggleFullscreen();
    }
    reset() {
        this._contentRef.instance.reset();
    }
    _getOverlayConfig() {
        const positionStrategy = this._overlay
            .position()
            .global()
            .centerHorizontally()
            .centerVertically();
        const overlayConfig = new OverlayConfig({
            hasBackdrop: true,
            scrollStrategy: this._overlay.scrollStrategies.noop(),
            positionStrategy,
            backdropClass: 'lightbox-gallery',
        });
        return overlayConfig;
    }
    _destroyOverlay() {
        if (this._overlayRef) {
            this._overlayRef.dispose();
            this._overlayRef = null;
        }
    }
    _listenToOutsideClick() {
        if (this._overlayRef) {
            merge(this._overlayRef.backdropClick(), this._overlayRef.detachments(), this._overlayRef.keydownEvents().pipe(filter((event) => {
                return event.key === 'escape';
            }))).subscribe((event) => {
                if (event) {
                    event.preventDefault();
                }
                this.close();
            });
        }
    }
    _listenToPopstateEvent() {
        fromEvent(window, 'popstate')
            .pipe(takeUntil(this._destroy$))
            .subscribe(() => {
            this.close();
        });
    }
    ngOnDestroy() {
        this._destroy$.next();
        this._destroy$.complete();
        this._destroyOverlay();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxComponent, deps: [{ token: DOCUMENT }, { token: i1$1.Overlay }, { token: i0.ViewContainerRef }, { token: i0.Renderer2 }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "19.2.1", type: MdbLightboxComponent, isStandalone: false, selector: "mdb-lightbox", inputs: { zoomLevel: "zoomLevel", fontAwesome: "fontAwesome" }, outputs: { lightboxOpen: "lightboxOpen", lightboxOpened: "lightboxOpened", lightboxSlide: "lightboxSlide", lightboxSlided: "lightboxSlided", lightboxZoomIn: "lightboxZoomIn", lightboxZoomedIn: "lightboxZoomedIn", lightboxZoomOut: "lightboxZoomOut", lightboxZoomedOut: "lightboxZoomedOut", lightboxClose: "lightboxClose", lightboxClosed: "lightboxClosed" }, queries: [{ propertyName: "lightboxItems", predicate: MdbLightboxItemDirective, descendants: true }], ngImport: i0, template: '<ng-content></ng-content>', isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'mdb-lightbox',
                    template: '<ng-content></ng-content>',
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    standalone: false,
                }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [DOCUMENT]
                }] }, { type: i1$1.Overlay }, { type: i0.ViewContainerRef }, { type: i0.Renderer2 }], propDecorators: { zoomLevel: [{
                type: Input
            }], fontAwesome: [{
                type: Input
            }], lightboxOpen: [{
                type: Output
            }], lightboxOpened: [{
                type: Output
            }], lightboxSlide: [{
                type: Output
            }], lightboxSlided: [{
                type: Output
            }], lightboxZoomIn: [{
                type: Output
            }], lightboxZoomedIn: [{
                type: Output
            }], lightboxZoomOut: [{
                type: Output
            }], lightboxZoomedOut: [{
                type: Output
            }], lightboxClose: [{
                type: Output
            }], lightboxClosed: [{
                type: Output
            }], lightboxItems: [{
                type: ContentChildren,
                args: [MdbLightboxItemDirective, { descendants: true }]
            }] } });

class MdbLightboxModule {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
    static ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxModule, declarations: [MdbLightboxComponent, MdbLightboxItemDirective, MdbLightboxModalComponent], imports: [CommonModule, OverlayModule], exports: [MdbLightboxComponent, MdbLightboxItemDirective, MdbLightboxModalComponent] });
    static ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxModule, imports: [CommonModule, OverlayModule] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.2.1", ngImport: i0, type: MdbLightboxModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [CommonModule, OverlayModule],
                    declarations: [MdbLightboxComponent, MdbLightboxItemDirective, MdbLightboxModalComponent],
                    exports: [MdbLightboxComponent, MdbLightboxItemDirective, MdbLightboxModalComponent],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { MdbLightboxComponent, MdbLightboxItemDirective, MdbLightboxModalComponent, MdbLightboxModule };
//# sourceMappingURL=mdb-angular-ui-kit-lightbox.mjs.map
